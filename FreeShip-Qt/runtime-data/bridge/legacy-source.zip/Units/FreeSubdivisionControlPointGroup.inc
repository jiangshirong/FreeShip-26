{------------------------------------------------------------------------------}
{                     TFreeSubdivisionControlPointGroup                        }
{------------------------------------------------------------------------------}

function TFreeSubdivisionControlPointGroup.FGetIndex: integer;
begin
  Result := Surface.FControlPointGroups.IndexOf(Self);
end;{TFreeSubdivisionControlPoint.FGetIndex}

function TFreeSubdivisionControlPointGroup.FGetSelected: boolean;
begin
  Result := Surface.FSelectedControlPointGroups.IndexOf(self) <> -1;
end;{TFreeSubdivisionControlPoint.FGetSelected}

function TFreeSubdivisionControlPointGroup.FGetVisible: boolean;
var
  I: integer;
  CFace: TFreeSubdivisionControlFace;
begin
  // a controlpoint group is visible if at least one of it's controlpoints
  //is visible
  Result := False;
  for i := 0 to FControlPoints.Count-1 do
    if FControlPoints[I].visible then
    begin
      Result := True;
      exit;
    end;
end;{TFreeSubdivisionControlPoint.FGetVisible}

procedure TFreeSubdivisionControlPointGroup.FSetSelected(val: boolean);
var
  index, i: integer;
begin
  Index := Surface.FSelectedControlPointGroups.IndexOf(self);

  if (Index >= 0) and Val then exit;
  if (Index < 0) and not Val then exit;

  for i:=0 to FControlPoints.Count-1 do
     FControlPoints[i].Selected:=val;

  if Val then
      Surface.FSelectedControlPointGroups.Add(self)
  else
      Surface.FSelectedControlPointGroups.Delete(index);

  Surface.ExecuteOnSelectItem(Self);
end;{TFreeSubdivisionControlPoint.FSetSelected}

procedure TFreeSubdivisionControlPointGroup.FSetLocked(val: boolean);
begin
  if Val <> FLocked then
  begin
    FLocked := Val;
  end;
end;{TFreeSubdivisionControlPoint.FSetLocked}

constructor TFreeSubdivisionControlPointGroup.Create(Owner: TFreeSubdivisionSurface);
begin
  inherited Create(Owner);
  if Owner = nil then
     Owner := nil;
  FControlPoints := TFasterListTFreeSubdivisionControlPoint.Create(true,false);
end;{TFreeSubdivisionControlPoint.Create}

destructor TFreeSubdivisionControlPointGroup.Destroy;
begin
  FreeAndNil(FControlPoints);
  inherited Destroy;
end;

procedure TFreeSubdivisionControlPointGroup.AddControlPoint(cp:TFreeSubdivisionControlPoint);
begin
 FControlPoints.Add(cp);
end;

procedure TFreeSubdivisionControlPointGroup.RemoveControlPoint(cp:TFreeSubdivisionControlPoint);
begin
 FControlPoints.DeleteItem(cp);
end;

procedure TFreeSubdivisionControlPointGroup.BreakGroup;
begin
 FControlPoints.Clear;
end;

procedure TFreeSubdivisionControlPointGroup.Delete;
var
  Index: integer;
  Edge: TFreesubdivisionEdge; //TFreesubdivisionControlEdge;
begin
  Selected := False;
  Surface.FSelectedControlPointGroups.DeleteItem(self);
  Surface.FControlPointGroups.DeleteItem(self);
  FControlPoints.Clear;
  Destroy;
end;{TFreeSubdivisionControlPoint.Delete}

function TFreeSubdivisionControlPointGroup.CalculateCenterPoint: T3DCoordinate;
var
  I,C: integer;
  P,Centre: T3DCoordinate;
begin
  Result := ZERO;
  Centre := ZERO;
  C:=FControlPoints.Count;
  for I := 0 to C-1 do
    begin
      P := FControlPoints[i].FCoordinate;
      Centre.X := Centre.X + P.X;
      Centre.Y := Centre.Y + P.Y;
      Centre.Z := Centre.Z + P.Z;
    end;
  Centre.X := Centre.X / C;
  Centre.Y := Centre.Y / C;
  Centre.Z := Centre.Z / C;
  Result := Centre;
end;{CalculateCenterPoint}

procedure TFreeSubdivisionControlPointGroup.Draw(Viewport: TFreeViewport);
var
  P, PA,PB: TPoint;
  Pz: TShadePoint;
  I: integer;
  P3D: T3DCoordinate;
  MFL: TFloatType;
  LabelPlacement: TLabelPlacement;
begin
  if Viewport.ViewportMode = vmWireframe then
  begin
    if (FName > '') then
    begin
      P3D := CalculateCenterPoint;

      if (Viewport.ViewType = fvBodyplan) then
        if P3D.X <= Surface.SplitSectionLocation then
          P3D.Y := -P3D.Y;

      P := Viewport.Project(P3D);

      if FControlPoints.Count>0 then
         Viewport.FontColor := FControlPoints[0].Color;
      ViewPort.PenColor:=Viewport.FontColor;
      ViewPort.Ellipse(P.X - 2, P.Y - 2, P.X + 2, P.Y + 2);
      ViewPort.Ellipse(P.X - 4, P.Y - 4, P.X + 4, P.Y + 4);
      if Viewport.Printing then
        ViewPort.TextOut(P.X + 2, P.Y + 2, FName)
      else
      begin
        LabelPlacement := Viewport.LabelLayout.Place('group:' + IntToHex(PtrUInt(Self), SizeOf(Pointer)*2),
          FName, P, Point(P.X + 2, P.Y + 2), Viewport.TextWidth(FName),
          Viewport.TextHeight(FName), lkPoint);
        if LabelPlacement.Visible then begin
          Viewport.DrawLabelLeader(P, LabelPlacement.Rect);
          Viewport.TextOut(LabelPlacement.Position.X, LabelPlacement.Position.Y, FName);
        end;
      end;

    end;
  end;
end;{TFreeSubdivisionControlPoint.Draw}

procedure TFreeSubdivisionControlPointGroup.LoadBinary(Source: TFreeFileBuffer);
var
  I, N, CPN: integer; SS:TStrings;
  Sel: boolean;
begin
  Source.LoadString(FName);
  SS:=TStringList.Create;
  try
    Source.LoadTStrings(SS);
    for i:=0 to SS.Count-1 do
    begin
      if not TryStrToInt(SS[i], CPN) then
        raise EReadError.CreateFmt('Invalid point group index: %s', [SS[i]]);
      RequireModelIndex(CPN, Surface.NumberOfControlPoints, 'point group control point');
      FControlPoints.Add(Surface.FControlPoints[CPN]);
    end;
  finally
    SS.Free;
  end;
end;{TFreeSubdivisionControlPoint.LoadBinary}

procedure TFreeSubdivisionControlPointGroup.LoadFromStream(
  var LineNr: integer; Strings: TStringList);
var
  Str: string; Strs:TStringArray;
  I,N,CPN: integer;
  sel: boolean;
begin
  Inc(LineNr);
  FName := Strings[LineNr];
  Inc(LineNr);
  Str := Strings[LineNr];
  Strs := Str.Split([#32]);
  N:= length(Strs);
  for i:=0 to N-1 do
    begin
    //CPN:=ReadIntFromStr(LineNr, Str);
    CPN:=StrToInt(Strs[i]);
    FControlPoints.Add(Surface.FControlPoints[CPN]);
    end;
end;{TFreeSubdivisionControlPoint.LoadFromStream}

procedure TFreeSubdivisionControlPointGroup.SaveBinary(Destination: TFreeFileBuffer);
var I,N,CPN: integer;  SS:TStrings;
begin
  Destination.Add(FName);
  //Destination.Add(FControlPoints.Count);
  SS:=TStringList.Create;
  for i:=0 to FControlPoints.Count-1 do
    begin
    CPN:=Surface.FControlPoints.IndexOf(FControlPoints[i]);
    SS.Add(IntToStr(CPN));
    end;
  Destination.Add(SS);
  SS.Free;
end;{TFreeSubdivisionControlPoint.SaveBinary}

procedure TFreeSubdivisionControlPointGroup.SaveToStream(Strings: TStringList);
var I,N,CPN: integer;
  Str: string;
begin
  Strings.Add(FName);
  CPN:=Surface.FControlPoints.IndexOf(FControlPoints[0]);
  Str:=IntToStr(CPN);
  for i:=1 to FControlPoints.Count-1 do
    begin
    CPN:=Surface.FControlPoints.IndexOf(FControlPoints[i]);
    Str:=Str+#32+IntToStr(CPN);
    end;
  Strings.Add(Str);
end;{TFreeSubdivisionControlPoint.SaveToStream}


