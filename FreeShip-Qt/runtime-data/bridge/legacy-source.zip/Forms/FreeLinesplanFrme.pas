{#############################################################################################}
{    This code is distributed as part of the FREE!ship project. FREE!ship is an               }
{    open source surface-modelling program based on subdivision surfaces and intended for     }
{    designing ships.                                                                         }

{    Copyright © 2005, by Martijn van Engeland                                                }
{    e-mail                  : Info@FREEship.org                                              }
{    FREE!ship project page  : https://sourceforge.net/projects/freeship                      }
{    FREE!ship homepage      : www.FREEship.org                                               }

{    This program is free software; you can redistribute it and/or modify it under            }
{    the terms of the GNU General Public License as published by the                          }
{    Free Software Foundation; either version 2 of the License, or (at your option)           }
{    any later version.                                                                       }

{    This program is distributed in the hope that it will be useful, but WITHOUT ANY          }
{    WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A          }
{    PARTICULAR PURPOSE. See the GNU General Public License for more details.                 }

{    You should have received a copy of the GNU General Public License along with             }
{    this program; if not, write to the Free Software Foundation, Inc.,                       }
{    59 Temple Place, Suite 330, Boston, MA 02111-1307 USA                                    }

{#############################################################################################}

unit FreeLinesplanFrme;

{$IFDEF FPC}
  {$MODE Delphi}
{$ENDIF}

interface

uses
{$IFnDEF FPC}
  Windows,
{$ELSE}
  LCLIntf, LCLType, LMessages, //
  {$IFDEF MSWINDOWS}Windows,{$ENDIF}
  PrintersDlgs, Printer4Lazarus, //FreePrinter,
{$ENDIF}
  //Messages,
  SysUtils,
  Variants,
  Classes,
  Graphics,
  Controls,
  Forms,
  Dialogs,
  FreeTypes,
  FreeShipUnit,
  FreeGeometry,
  FasterList,
  ExtCtrls,
  ComCtrls,
  LCLTranslator,
  //ToolWin,
  Printers,
  Math,
  ImgList,
  ActnList, StdCtrls, Spin,
  FreeStringUtils, FreeLabelLayout, FreeSmoothLines, FreeVectorFillCache, FreeMeshFingerprint, SHA1;

const
  SpacePercentage = 0.20;
  Textspace = 0.05;

type
  TLinesplanViewport=class(TFreeViewport)
  private
    FRendering:Boolean;
    FComposeTarget:TBitmap;
    FNativeResizeFrame:TBitmap;
    FSkipPreparedPaint:Boolean;
    FObservedWidth,FObservedHeight:Integer;
    procedure ErasePreparedFrame(var Message:TLMEraseBkgnd);message LM_ERASEBKGND;
  protected
    procedure WndProc(var Message:TLMessage);override;
    procedure Resize;override;
    procedure Paint;override;
  public
    destructor Destroy;override;
    procedure ComposeFrame;
    procedure PrepareFrame;
    procedure PrepareNativeResize(OuterWidth,OuterHeight:Integer);
    function AdoptNativeResize:Boolean;
    procedure DiscardNativeResize;
    procedure PresentPreparedFrame(Target:TCanvas;X:Integer=0;Y:Integer=0);
  end;
  TLinesplanView = (lvProfile, lvAftBody, lvFrontBody, lvPlan);
  TLinesplanViews = set of TLinesplanView;

  { TFreeLinesplanFrame }

  TFreeLinesplanFrame = class(TFrame)
    SpinEdit1: TSpinEdit;
    ToolButton15: TToolButton;
    Viewport: TFreeViewport;
    ActionList1: TActionList;
    ZoomExtents: TAction;
    SaveBitmap: TAction;
    ZoomIn: TAction;
    ZoomOut: TAction;
    ExportDXF: TAction;
    ShowFillColor: TAction;
    MenuImages: TImageList;
    ToolBar1: TToolBar;
    ToolButton5: TToolButton;
    ToolButton8: TToolButton;
    ToolButton9: TToolButton;
    ToolButton6: TToolButton;
    ToolButton19: TToolButton;
    ToolButton14: TToolButton;
    ToolButton7: TToolButton;
    ToolButton13: TToolButton;
    Print: TAction;
    ToolButton1: TToolButton;
    PrintDialog: TPrintDialog;
    UseLights: TAction;
    ToolButton2: TToolButton;
    ShowMonochrome: TAction;
    ToolButton3: TToolButton;
    MirrorPlanView: TAction;
    ToolButton4: TToolButton;
    procedure SpinEdit1Change(Sender: TObject);
    procedure ViewportRequestExtents(Sender: TObject;
      var Min, Max: T3DCoordinate);
    procedure ViewportRedraw(Sender: TObject);
    procedure ZoomExtentsExecute(Sender: TObject);
    procedure ZoomInExecute(Sender: TObject);
    procedure ZoomOutExecute(Sender: TObject);
    procedure ShowFillColorExecute(Sender: TObject);
    procedure PrintExecute(Sender: TObject);
    procedure ViewportMouseMove(Sender: TObject;
      Shift: TShiftState; X, Y: integer);
    procedure ViewportMouseUp(Sender: TObject; Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
    procedure ViewportMouseDown(Sender: TObject;
      Button: TMouseButton; Shift: TShiftState; X, Y: integer);
    procedure SaveBitmapExecute(Sender: TObject);
    procedure UseLightsExecute(Sender: TObject);
    procedure ShowMonochromeExecute(Sender: TObject);
    procedure MirrorPlanViewExecute(Sender: TObject);
    procedure ExportDXFExecute(Sender: TObject);
  private   { Private declarations }
    FTrace: TStringList;
    FTracePath: string;
    FTraceStart: QWord;
    FTraceSnapshot:Boolean;
    FFillVector:TVectorFillCache;
    FDiskFillPath:string;
    FDiskFillDirty:Boolean;
    FFillVectorKey:string;
    FInteractionImage: TBitmap;
    FInteractionKey: string;
    FInteractionOrigin: TPoint;
    FInteractionScale: TFloatType;
    FInteractionUntil: QWord;
    FInteractionDragging: Boolean;
    FPanDragStarted: Boolean;
    FLastLabelScale: Double;
    FLastLabelContext: string;
    FInteractionTimer: TTimer;
    FFillCache: TBitmap;
    FFillCacheKey: string;
    FFreeShip: TFreeShip;
    FModelLength: TFloatType;
    FModelHeight: TFloatType;
    FModelBeam: TFloatType;
    FDiagonalWidth: TFloatType;
    FMin3D, FMax3D: T3DCoordinate;
    FProfileOrigin: T3DCoordinate;
    FAftOrigin: T3DCoordinate;
    FFontSize: integer;
    FFrontOrigin: T3DCoordinate;
    FPlanOrigin: T3DCoordinate;
    FInitialPosition: TPoint;
    procedure TraceEvent(const Event, Detail: string);
    procedure ViewportResizing(Sender: TObject);
    procedure BeginInteraction;
    procedure FinishInteraction(Sender: TObject);
    function DrawVectorFill:Boolean;
    function DrawInteractionPreview: Boolean;
    procedure ViewportMouseWheel(Sender: TObject; Shift: TShiftState;
      WheelDelta: Integer; MousePos: TPoint; var Handled: Boolean);
    function FillCacheKey(IncludeTransform: Boolean = True): string;
    procedure FSetFreeShip(Val: TFreeShip);
    procedure CreateViewport;
    function LabelBackgroundCost(const R: TRect): integer;
  private
  protected
    procedure WndProc(var Message:TLMessage);override;
    procedure EraseBackground(DC:HDC);override;
  public    { Public declarations }
    constructor Create(TheOwner: TComponent); override;
    destructor Destroy; override;
    procedure TraceNativeMessage(const Layer,Phase:string;const Message:TLMessage);
    procedure TracePresentation(const Stage:string;DC:HDC=0;const Extra:string='');
    procedure PresentClientBackground(Target:TCanvas);
    procedure InvalidateRenderCache;
    procedure UpdateMenu;
    property FreeShip: TFreeShip
      read FFreeShip write FSetFreeShip;
    property FontSize: integer read FFontSize write FFontSize;
  end;

function LinesplanNativeLayoutReady(Control:TWinControl;DC:HDC):Boolean;

var
  FreeLinesplanFrame: TFreeLinesplanFrame;

implementation

uses FreeStringsUnit;

var LinesplanTraceSession:Boolean=False;

function LinesplanNativeLayoutReady(Control:TWinControl;DC:HDC):Boolean;
{$IFDEF MSWINDOWS}
var R:TRect;CW,CH:Integer;
{$ENDIF}
begin
  Result:=True;
  {$IFDEF MSWINDOWS}
  // Memory/printer canvases may prepare a future frame. A native window DC
  // may display it only after this control AND its ancestors have committed
  // their new HWND geometry. LCL sends size notifications before that commit.
  if (DC=0) or (Windows.WindowFromDC(DC)=0) then Exit;
  while Control<>nil do begin
    if Control.HandleAllocated then begin
      // A newly created Lazarus form can keep client-size Bounds until its
      // first interface size notification. Native client geometry is the
      // authority for forms; child Bounds include their own border correctly.
      if not (Control is TCustomForm) then begin
        if not Windows.GetWindowRect(Control.Handle,R) then Exit(False);
        if ((R.Right-R.Left)<>Control.Width) or ((R.Bottom-R.Top)<>Control.Height) then Exit(False);
      end;
      if not Windows.GetClientRect(Control.Handle,R) then Exit(False);
      CW:=Control.CachedClientWidth;CH:=Control.CachedClientHeight;
      if ((CW>=0) and ((R.Right-R.Left)<>CW)) or
         ((CH>=0) and ((R.Bottom-R.Top)<>CH)) then Exit(False);
    end;
    Control:=Control.Parent;
  end;
  {$ENDIF}
end;

procedure TLinesplanViewport.WndProc(var Message:TLMessage);
var Frame:TFreeLinesplanFrame;
begin
  Frame:=nil;
  if (Owner is TFreeLinesplanFrame) and not (csDestroying in ComponentState) and
    not (csDestroying in Owner.ComponentState) then Frame:=TFreeLinesplanFrame(Owner);
  if Frame<>nil then Frame.TraceNativeMessage('viewport','before',Message);
  inherited WndProc(Message);
  if Frame<>nil then Frame.TraceNativeMessage('viewport','after',Message);
end;

procedure TFreeLinesplanFrame.WndProc(var Message:TLMessage);
begin
  if not (csDestroying in ComponentState) then TraceNativeMessage('frame','before',Message);
  inherited WndProc(Message);
  if not (csDestroying in ComponentState) then TraceNativeMessage('frame','after',Message);
end;

procedure TFreeLinesplanFrame.TraceNativeMessage(const Layer,Phase:string;const Message:TLMessage);
var Extra:string;Pos:LMessages.PWindowPos;
begin
  if FTrace=nil then Exit;
  if (Message.Msg<>LM_SYSCOMMAND) and not (Message.Msg in [LM_SIZE,LM_PAINT,LM_ERASEBKGND,LM_WINDOWPOSCHANGING,LM_WINDOWPOSCHANGED,LM_SHOWWINDOW]) then Exit;
  Extra:='msg='+IntToHex(Message.Msg,4);
  if Message.Msg in [LM_WINDOWPOSCHANGING,LM_WINDOWPOSCHANGED] then begin
    Pos:=TLMWindowPosMsg(Message).WindowPos;
    if Pos<>nil then Extra:=Extra+';flags='+IntToHex(Pos^.flags,8)+';proposed='+
      IntToStr(Pos^.x)+','+IntToStr(Pos^.y)+','+IntToStr(Pos^.cx)+','+IntToStr(Pos^.cy);
  end;
  TracePresentation(Layer+'.'+Phase,0,Extra);
end;

procedure TFreeLinesplanFrame.TracePresentation(const Stage:string;DC:HDC;const Extra:string);
var Host:TCustomForm;Detail:string;R:TRect;
  function SizeText(W,H:Integer):string;
  begin Result:=IntToStr(W)+','+IntToStr(H) end;
  function Snapshot(C:TWinControl):string;
  var CR,WR:TRect;
  begin
    Result:='none';if C=nil then Exit;
    Result:=SizeText(C.CachedClientWidth,C.CachedClientHeight);
    if C.HandleAllocated then begin
      {$IFDEF MSWINDOWS}
      Windows.GetClientRect(C.Handle,CR);Windows.GetWindowRect(C.Handle,WR);
      Result:=Result+'/'+SizeText(CR.Right-CR.Left,CR.Bottom-CR.Top)+'/'+
        IntToStr(WR.Left)+','+IntToStr(WR.Top)+','+IntToStr(WR.Right)+','+IntToStr(WR.Bottom);
      {$ENDIF}
    end;
  end;
begin
  if (FTrace=nil) or FTraceSnapshot or (Viewport=nil) then Exit;
  FTraceSnapshot:=True;
  try
    Host:=GetParentForm(Self);
    Detail:='stage='+Stage+';host='+Snapshot(Host)+';frame='+Snapshot(Self)+';viewport='+Snapshot(Viewport)+
      ';buffer='+SizeText(Viewport.GetDrawingBuffer.Width,Viewport.GetDrawingBuffer.Height)+
      ';scale='+FloatToStr(Viewport.Scale)+';pan='+SizeText(Viewport.Pan.X,Viewport.Pan.Y);
    if Viewport is TLinesplanViewport then Detail:=Detail+';rendering='+IntToStr(Ord(TLinesplanViewport(Viewport).FRendering));
    {$IFDEF MSWINDOWS}
    if DC<>0 then begin
      Windows.GetClipBox(DC,R);
      Detail:=Detail+';dc_window='+IntToHex(Windows.WindowFromDC(DC),16)+';dc_clip='+
        IntToStr(R.Left)+','+IntToStr(R.Top)+','+IntToStr(R.Right)+','+IntToStr(R.Bottom);
    end;
    {$ENDIF}
    if Extra<>'' then Detail:=Detail+';'+Extra;
    TraceEvent('native',Detail);
  finally FTraceSnapshot:=False end;
end;

procedure TLinesplanViewport.Resize;
var W,H:Integer;
begin
  W:=ClientWidth;H:=ClientHeight;
  if (W<>FObservedWidth) or (H<>FObservedHeight) then begin
    FObservedWidth:=W;FObservedHeight:=H;
    if (Owner is TFreeLinesplanFrame) and
      (TFreeLinesplanFrame(Owner).Viewport=Self) and
      ([csLoading,csDestroying]*TFreeLinesplanFrame(Owner).ComponentState=[]) and
      ([csLoading,csDestroying]*ComponentState=[]) then
      TFreeLinesplanFrame(Owner).ViewportResizing(Self);
  end;
  inherited Resize;
end;

destructor TLinesplanViewport.Destroy;
begin
  FreeAndNil(FNativeResizeFrame);
  FreeAndNil(FComposeTarget);
  inherited Destroy;
end;

procedure TLinesplanViewport.PrepareNativeResize(OuterWidth,OuterHeight:Integer);
var Saved:TBitmap;OldBounds:TRect;
begin
  if FRendering or Printing or ExportingBitmap or (OuterWidth<=8) or (OuterHeight<=8) then Exit;
  if (OuterWidth=Width) and (OuterHeight=Height) then Exit;
  FreeAndNil(FNativeResizeFrame);FSkipPreparedPaint:=False;
  Saved:=TBitmap.Create;OldBounds:=BoundsRect;
  Saved.SetSize(GetDrawingBuffer.Width,GetDrawingBuffer.Height);
  Saved.Canvas.CopyRect(Rect(0,0,Saved.Width,Saved.Height),GetDrawingBuffer.Canvas,
    Rect(0,0,Saved.Width,Saved.Height));
  DisableAutoSizing;
  try
    // Explicit memory-only preparation BEFORE the top-level HWND starts its
    // native size transition. The visible child HWND stays at its old size.
    SetBounds(Left,Top,OuterWidth,OuterHeight);
    ComposeFrame;
    FNativeResizeFrame:=TBitmap.Create;
    FNativeResizeFrame.SetSize(GetDrawingBuffer.Width,GetDrawingBuffer.Height);
    FNativeResizeFrame.Canvas.CopyRect(Rect(0,0,FNativeResizeFrame.Width,FNativeResizeFrame.Height),
      GetDrawingBuffer.Canvas,Rect(0,0,FNativeResizeFrame.Width,FNativeResizeFrame.Height));
  finally
    SetBounds(OldBounds.Left,OldBounds.Top,OldBounds.Right-OldBounds.Left,OldBounds.Bottom-OldBounds.Top);
    InitializeViewport(Min3D,Max3D);
    GetDrawingBuffer.SetSize(Saved.Width,Saved.Height);
    GetDrawingBuffer.Canvas.CopyRect(Rect(0,0,Saved.Width,Saved.Height),Saved.Canvas,Rect(0,0,Saved.Width,Saved.Height));
    EnableAutoSizing;Saved.Free;
  end;
end;

function TLinesplanViewport.AdoptNativeResize:Boolean;
begin
  Result:=(FNativeResizeFrame<>nil) and (FNativeResizeFrame.Width=ClientWidth) and
    (FNativeResizeFrame.Height=ClientHeight);
  if not Result then Exit;
  InitializeViewport(Min3D,Max3D);
  GetDrawingBuffer.SetSize(ClientWidth,ClientHeight);
  GetDrawingBuffer.Canvas.CopyRect(Rect(0,0,ClientWidth,ClientHeight),FNativeResizeFrame.Canvas,
    Rect(0,0,ClientWidth,ClientHeight));
  FreeAndNil(FNativeResizeFrame);FSkipPreparedPaint:=True;
  if Owner is TFreeLinesplanFrame then TFreeLinesplanFrame(Owner).TracePresentation('precomposed.adopted');
end;

procedure TLinesplanViewport.DiscardNativeResize;
begin
  FreeAndNil(FNativeResizeFrame);FSkipPreparedPaint:=False;
end;

procedure TLinesplanViewport.ComposeFrame;
var SavedCanvas:TCanvas;
begin
  if FRendering then Exit;
  if (not Printing) and (not ExportingBitmap) and
    ((GetDrawingBuffer.Width<>ClientWidth) or (GetDrawingBuffer.Height<>ClientHeight)) then
    InitializeViewport(Min3D,Max3D);
  if FComposeTarget=nil then begin
    FComposeTarget:=TBitmap.Create;
    FComposeTarget.SetSize(1,1);
  end;
  if Owner is TFreeLinesplanFrame then TFreeLinesplanFrame(Owner).TracePresentation('compose.begin');
  SavedCanvas:=DrawingCanvas;
  FRendering:=True;
  try
    // Base Paint ends by copying to DrawingCanvas. Keep that incidental copy
    // on a clipped memory surface, never on the window outside its paint DC.
    DrawingCanvas:=FComposeTarget.Canvas;
    inherited Paint;
  finally
    DrawingCanvas:=SavedCanvas;FRendering:=False;
    if Owner is TFreeLinesplanFrame then TFreeLinesplanFrame(Owner).TracePresentation('compose.end');
  end;
end;

procedure TLinesplanViewport.Paint;
begin
  if FRendering then Exit;
  if Printing or ExportingBitmap then begin inherited Paint;Exit end;
  if not LinesplanNativeLayoutReady(Self,Canvas.Handle) then begin
    PresentPreparedFrame(Canvas); // Queue paint; do not block native geometry commit.
    Exit;
  end;
  AdoptNativeResize;
  if FSkipPreparedPaint then FSkipPreparedPaint:=False else ComposeFrame;
  PresentPreparedFrame(Canvas);
end;

procedure TLinesplanViewport.PrepareFrame;
begin
  if Owner is TFreeLinesplanFrame then TFreeLinesplanFrame(Owner).FinishInteraction(nil);
  ComposeFrame;
end;

procedure TLinesplanViewport.PresentPreparedFrame(Target:TCanvas;X,Y:Integer);
var Buffer:TBitmap;
begin
  if Owner is TFreeLinesplanFrame then TFreeLinesplanFrame(Owner).TracePresentation('present.begin',Target.Handle);
  if not LinesplanNativeLayoutReady(Self,Target.Handle) then begin
    // Do not block HWND layout with a future-size render. This method can be
    // reached synchronously inside SetWindowPos, before child sizes commit.
    // Retain the previous surface and compose only after the geometry barrier.
    if Owner is TFreeLinesplanFrame then TFreeLinesplanFrame(Owner).TracePresentation('present.deferred',Target.Handle);
    Invalidate;Exit;
  end;
  AdoptNativeResize;
  Buffer:=GetDrawingBuffer;
  if (not FRendering) and (Parent<>nil) and (ClientWidth>0) and (ClientHeight>0) and
    not Printing and not ExportingBitmap and
    ((Buffer.Width<>ClientWidth) or (Buffer.Height<>ClientHeight)) then begin
    // This also covers the erase message before the first paint after a
    // maximize/restore. Never expose a scaled composite containing text.
    ComposeFrame;
    Buffer:=GetDrawingBuffer;
  end;
  if (Buffer<>nil) and (Buffer.Width=ClientWidth) and (Buffer.Height=ClientHeight) and
    (Buffer.Width>0) and (Buffer.Height>0) then
    Target.Draw(X,Y,Buffer)
  else begin
    Target.Brush.Color:=clWhite;Target.Brush.Style:=bsSolid;
    Target.FillRect(Rect(X,Y,X+ClientWidth,Y+ClientHeight));
  end;
  if Owner is TFreeLinesplanFrame then TFreeLinesplanFrame(Owner).TracePresentation('present.end',Target.Handle);
end;

procedure TLinesplanViewport.ErasePreparedFrame(var Message:TLMEraseBkgnd);
var Target:TCanvas;
begin
  if (Message.DC=0) or FRendering then begin Message.Result:=1;Exit end;
  Target:=TCanvas.Create;
  try
    Target.Handle:=Message.DC;
    PresentPreparedFrame(Target);
  finally Target.Handle:=0;Target.Free end;
  Message.Result:=1;
end;


{$IFnDEF FPC}
  {$R *.dfm}

{$ELSE}
  {$R *.lfm}
{$ENDIF}

function CalculateSpace(Percentage, Min, Max: TFloatType): TFloatType;
begin
  Result := Percentage * (Max - Min);
end;{Space}

{
   object Viewport: TFreeViewport
    Left = 0
    Height = 465
    Top = 29
    Width = 761
    Angle = 90
    Align = alClient
    BackgroundImage.Alpha = 255
    BackgroundImage.Owner = Viewport
    BackgroundImage.Quality = 100
    BackgroundImage.Scale = 1
    BackgroundImage.ShowInView = fvBodyplan
    BackgroundImage.Tolerance = 5
    BackgroundImage.Transparent = False
    BackgroundImage.TransparentColor = clBlack
    BackgroundImage.Visible = True
    BevelOuter = bvLowered
    CameraType = ftStandard
    Color = clWhite
    DoubleBuffer = True
    Elevation = 90
    Margin = 1
    ViewType = fvPlan
    ViewportMode = vmWireFrame
    OnMouseDown = ViewportMouseDown
    OnMouseMove = ViewportMouseMove
    OnRedraw = ViewportRedraw
    OnRequestExtents = ViewportRequestExtents
  end
}

procedure TFreeLinesplanFrame.CreateViewport;
begin
  Viewport := TLinesplanViewport.Create(Self);
  with Viewport do
  begin
    Parent := Self;
    Left := 0;
    Height := 465;
    Top := 29;
    Width := 761;
    Angle := 90;
    Align := alClient;
    BackgroundImage.Alpha := 255;
    BackgroundImage.Owner := Viewport;
    BackgroundImage.Quality := 100;
    BackgroundImage.Scale := 1;
    BackgroundImage.ShowInView := fvBodyplan;
    BackgroundImage.Tolerance := 5;
    BackgroundImage.Transparent := False;
    BackgroundImage.TransparentColor := clBlack;
    BackgroundImage.Visible := True;
    BevelOuter := bvLowered;
    CameraType := ftStandard;
    Color := clWhite;
    DoubleBuffer := True;
    ParentDoubleBuffered:=False;DoubleBuffered:=True;
    Elevation := 90;
    Margin := 1;
    ViewType := fvPlan;
    ViewportMode := vmWireFrame;
    OnMouseDown := ViewportMouseDown;
    OnMouseMove := ViewportMouseMove;
    OnMouseUp := ViewportMouseUp;
    OnMouseWheel := ViewportMouseWheel;
    // TLinesplanViewport.Resize starts preview at the size event itself; a
    // delayed OnResize must not restart it after resizing has already stopped.
    DeferredTransformRedraw := True;
    LabelLayout.AnimationEnabled := False;
    OnRedraw := ViewportRedraw;
    OnRequestExtents := ViewportRequestExtents;
  end;
end;


constructor TFreeLinesplanFrame.Create(TheOwner: TComponent);
var TraceMarker:string;
begin
  inherited Create(TheOwner);
  Color:=clWhite;ParentBackground:=False;ParentDoubleBuffered:=False;DoubleBuffered:=True;
  CreateViewport;
  FInteractionTimer := TTimer.Create(Self);
  FInteractionTimer.Enabled := False;
  FInteractionTimer.Interval := 16;
  FInteractionTimer.OnTimer := FinishInteraction;
  TraceMarker:=ExtractFilePath(ParamStr(0))+'.linesplan-trace-once';
  if FindCmdLineSwitch('trace-linesplan',True) or FindCmdLineSwitch('-trace-linesplan',True) or FileExists(TraceMarker) or LinesplanTraceSession then
  begin
    LinesplanTraceSession:=True;
    if FileExists(TraceMarker) then SysUtils.DeleteFile(TraceMarker);
    FTrace := TStringList.Create;
    FTraceStart := GetTickCount64;
    FTracePath := IncludeTrailingPathDelimiter(GetTempDir) + 'FreeShip-linesplan-' +
      IntToStr(GetProcessID) + '-' + IntToStr(FTraceStart) + '.tsv';
    FTrace.Add('elapsed_ms' + #9 + 'event' + #9 + 'detail');
    TraceEvent('created', 'pid=' + IntToStr(GetProcessID));
  end;
end;

procedure TFreeLinesplanFrame.PresentClientBackground(Target:TCanvas);
var Surface:TBitmap;
begin
  TracePresentation('host-background.begin',Target.Handle);
  if not LinesplanNativeLayoutReady(Self,Target.Handle) then begin
    TracePresentation('host-background.deferred',Target.Handle);Invalidate;Exit;
  end;
  // Growth can expose the host before the child window covers its new area.
  // Compose the host background and current-size chart offscreen as one image.
  Realign;
  if Viewport<>nil then
    Viewport.SetBounds(0,ToolBar1.Top+ToolBar1.Height,ClientWidth,
      Max(0,ClientHeight-ToolBar1.Top-ToolBar1.Height));
  if not LinesplanNativeLayoutReady(Viewport,Target.Handle) then begin
    TracePresentation('host-background.deferred',Target.Handle);Invalidate;Exit;
  end;
  Surface:=TBitmap.Create;
  try
    Surface.SetSize(ClientWidth,ClientHeight);
    Surface.Canvas.Brush.Color:=Color;
    Surface.Canvas.FillRect(Rect(0,0,ClientWidth,ClientHeight));
    if (Viewport is TLinesplanViewport) and (FFreeShip<>nil) then
      TLinesplanViewport(Viewport).PresentPreparedFrame(Surface.Canvas,Viewport.Left,Viewport.Top);
    Target.Draw(0,0,Surface);
  finally Surface.Free end;
  TracePresentation('host-background.end',Target.Handle);
end;

procedure TFreeLinesplanFrame.EraseBackground(DC:HDC);
var Target:TCanvas;
begin
  if (DC=0) or (FFreeShip=nil) or (csDestroying in ComponentState) then begin inherited EraseBackground(DC);Exit end;
  Target:=TCanvas.Create;
  try Target.Handle:=DC;PresentClientBackground(Target)
  finally Target.Handle:=0;Target.Free end;
end;

procedure TFreeLinesplanFrame.TraceEvent(const Event, Detail: string);
begin
  if (FTrace = nil) or (FTrace.Count >= 2000) then Exit;
  FTrace.Add(IntToStr(GetTickCount64-FTraceStart) + #9 + Event + #9 + Detail);
  // Diagnostic mode only: bound the trace and flush in small batches.
  if (FTrace.Count = 2) or ((Event<>'native') and (FTrace.Count mod 16 = 0)) or
    (Event = 'idle') or (Event = 'closed') then
    try FTrace.SaveToFile(FTracePath) except end;
end;

procedure TFreeLinesplanFrame.BeginInteraction;
begin
  TraceEvent('input', 'image=' + SysUtils.BoolToStr(FInteractionImage<>nil,True) +
    '; printing=' + SysUtils.BoolToStr(Viewport.Printing,True) +
    '; export=' + SysUtils.BoolToStr(Viewport.ExportingBitmap,True));
  if (FInteractionImage = nil) or Viewport.Printing or Viewport.ExportingBitmap then Exit;
  Viewport.PauseLabelAnimation;
  FInteractionUntil := GetTickCount64 + 500;
  FInteractionTimer.Enabled := True;
end;

procedure TFreeLinesplanFrame.FinishInteraction(Sender: TObject);
begin
  if (Sender <> nil) and (FInteractionDragging or (GetTickCount64 < FInteractionUntil)) then Exit;
  FInteractionDragging := False;
  TraceEvent('idle','timer=' + SysUtils.BoolToStr(Sender<>nil,True));
  if FInteractionTimer <> nil then FInteractionTimer.Enabled := False;
  if FInteractionUntil <> 0 then
  begin
    FInteractionUntil := 0;
    Viewport.Invalidate;
  end;
end;

procedure TFreeLinesplanFrame.ViewportMouseUp(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  FInteractionDragging := False;
  if FInteractionUntil <> 0 then
  begin
    FInteractionUntil := GetTickCount64 + 500;
    FInteractionTimer.Enabled := True;
  end;
end;

procedure TFreeLinesplanFrame.ViewportResizing(Sender: TObject);
begin
  // Reuse fill-only pixels during a resize, but repaint text and strokes at
  // their native size on every presented frame.
  BeginInteraction;
end;

procedure TFreeLinesplanFrame.ViewportMouseWheel(Sender: TObject; Shift: TShiftState;
  WheelDelta: Integer; MousePos: TPoint; var Handled: Boolean);
begin
  BeginInteraction;
  Handled := False; // Let the viewport retain its existing cursor-centred zoom.
end;

function TFreeLinesplanFrame.DrawVectorFill:Boolean;
var A,B:TPoint;
begin
 Result:=False;
 if (FFillVector=nil) or not FFillVector.Valid then Exit;
 A:=Viewport.Project(SetPoint(FFillVector.MinX,FFillVector.MaxY,0));
 B:=Viewport.Project(SetPoint(FFillVector.MaxX,FFillVector.MinY,0));
 Result:=FFillVector.Draw(Viewport.DrawingCanvas,Rect(A.X,A.Y,B.X,B.Y));
end;

function TFreeLinesplanFrame.DrawInteractionPreview: Boolean;
var Origin: TPoint; Ratio: Double; R: TRect;
begin
  Result := False;
  {$IFDEF MSWINDOWS}
  if ((FFillVector=nil) or (FFillVectorKey<>FillCacheKey(False))) and not Viewport.Printing and not Viewport.ExportingBitmap and
    not ShowMonochrome.Checked and ShowFillColor.Checked then begin
    FreeAndNil(FFillVector);
    FDiskFillPath:=IncludeTrailingPathDelimiter(GetEnvironmentVariable('LOCALAPPDATA'))+
      'FreeShip26'+PathDelim+'LinesplanCache-v2'+PathDelim+
      SHA1Print(SHA1String('fill-v2;'+MeshFillFingerprint(FreeShip.Surface)+';'+FillCacheKey(False)))+'.fsc';
    FFillVector:=TVectorFillCache.Create;
    if FFillVector.LoadDisk(FDiskFillPath) then begin
      FFillVectorKey:=FillCacheKey(False);TraceEvent('disk-hit',FDiskFillPath);
    end else begin FreeAndNil(FFillVector);TraceEvent('disk-miss',FDiskFillPath) end;
  end;
  {$ENDIF}
  {$IFDEF MSWINDOWS}
  if not ShowMonochrome.Checked and ShowFillColor.Checked and not Viewport.Printing and
    not Viewport.ExportingBitmap and (FFillVectorKey=FillCacheKey(False)) then begin
    Result:=DrawVectorFill;
    if Result and (FTrace<>nil) then TraceEvent('fill-cache','zoom='+FloatToStr(Viewport.Zoom)+';mode='+FFillVector.LastDrawMode);
  end;
  Exit; // Windows never scales a lower-resolution fill bitmap as a preview.
  {$ENDIF}
  if ShowMonochrome.Checked or not ShowFillColor.Checked or
    (FInteractionKey <> FillCacheKey(False)) then Exit;
  if (FInteractionUntil = 0) or (FInteractionImage = nil) or Viewport.Printing or Viewport.ExportingBitmap or
    (Viewport.DrawingCanvas <> Viewport.GetDrawingBuffer.Canvas) or
    (Viewport.GetDrawingBuffer.Width <> Viewport.ClientWidth) or
    (Viewport.GetDrawingBuffer.Height <> Viewport.ClientHeight) or
    (FInteractionScale <= 0) then
  begin
    TraceEvent('preview-rejected', 'active=' + SysUtils.BoolToStr(FInteractionUntil<>0,True) +
      '; image=' + SysUtils.BoolToStr(FInteractionImage<>nil,True) +
      '; printing=' + SysUtils.BoolToStr(Viewport.Printing,True) +
      '; export=' + SysUtils.BoolToStr(Viewport.ExportingBitmap,True) +
      '; viewport=' + IntToStr(Viewport.ClientWidth) + 'x' + IntToStr(Viewport.ClientHeight) +
      '; buffer=' + IntToStr(Viewport.GetDrawingBuffer.Width) + 'x' + IntToStr(Viewport.GetDrawingBuffer.Height));
    Exit;
  end;
  if not FInteractionDragging and (GetTickCount64 >= FInteractionUntil) then
  begin FinishInteraction(nil); Exit end;
  Origin := Viewport.Project(ZERO);
  Ratio := Viewport.Scale * Viewport.Zoom / FInteractionScale;
  // Keep extreme zoom values out of GDI's signed device-coordinate range.
  if (Ratio <= 0) or (Ratio * Max(FInteractionImage.Width,FInteractionImage.Height) > 1E7) then Exit;
  R.Left := Round(Origin.X - Ratio * FInteractionOrigin.X);
  R.Top := Round(Origin.Y - Ratio * FInteractionOrigin.Y);
  R.Right := R.Left + Round(Ratio * FInteractionImage.Width);
  R.Bottom := R.Top + Round(Ratio * FInteractionImage.Height);
  if (R.Right-R.Left=FInteractionImage.Width) and
     (R.Bottom-R.Top=FInteractionImage.Height) then
    Viewport.DrawingCanvas.Draw(R.Left,R.Top,FInteractionImage)
  else
    Viewport.DrawingCanvas.StretchDraw(R, FInteractionImage);
  TraceEvent('preview','zoom=' + FloatToStr(Viewport.Zoom));
  Result := True;
end;

procedure TFreeLinesplanFrame.InvalidateRenderCache;
begin
  TraceEvent('invalidate','');
  FDiskFillPath:='';FDiskFillDirty:=False;
  if Viewport is TLinesplanViewport then TLinesplanViewport(Viewport).DiscardNativeResize;
  FreeAndNil(FFillVector);FFillVectorKey:='';
  FFillCacheKey := '';
  FLastLabelContext := '';
  FinishInteraction(nil);
  FreeAndNil(FInteractionImage);
  FInteractionKey := '';
end;

destructor TFreeLinesplanFrame.Destroy;
begin
  FSetFreeShip(nil);
  TraceEvent('closed','');
  FreeAndNil(FTrace);
  FreeAndNil(FInteractionTimer);
  FreeAndNil(FInteractionImage);
  FreeAndNil(FFillVector);
  if FFreeShip <> nil then FFreeShip.LinesplanFrame := nil;
  FreeAndNil(FFillCache);
  inherited Destroy;
end;

function TFreeLinesplanFrame.FillCacheKey(IncludeTransform: Boolean): string;
  function F(V: TFloatType): string;
  begin Result := FloatToStrF(V, ffGeneral, 17, 0) + ';' end;
  function C(P: T3DCoordinate): string;
  begin Result := F(P.X) + F(P.Y) + F(P.Z) end;
var P: TPoint; I: Integer; Transform: string;
begin
  P := Viewport.Project(ZERO);
  Transform := '';
  if IncludeTransform then Transform := IntToStr(Viewport.ClientWidth) + ';' +
    IntToStr(Viewport.ClientHeight) + ';' + IntToStr(P.X) + ';' + IntToStr(P.Y) + ';' +
    IntToStr(Viewport.Pan.X) + ';' + IntToStr(Viewport.Pan.Y) + ';' + F(Viewport.Zoom) +
    F(Viewport.Scale) + C(Viewport.CameraLocation) + C(Viewport.Min3D) + C(Viewport.Max3D);
  // The fill atlas is model-space content. Window dimensions and fitted
  // camera/scale belong only to the exact screen cache, not atlas identity.
  Result := Transform + F(Viewport.Angle) + F(Viewport.Elevation) +
    C(FMin3D) + C(FMax3D) +
    C(FProfileOrigin) + C(FAftOrigin) + C(FFrontOrigin) + C(FPlanOrigin) +
    F(FreeShip.ProjectSettings.ProjectDraft) +
    IntToStr(Ord(FreeShip.ProjectSettings.ProjectShadeUnderwaterShip)) + ';' +
    IntToStr(FreeShip.ProjectSettings.ProjectUnderWaterColor) + ';' +
    IntToStr(Viewport.Color) + ';' + IntToStr(Ord(UseLights.Checked)) + ';' +
    IntToStr(Ord(MirrorPlanview.Checked));
  for I := 0 to FreeShip.NumberOfLayers - 1 do
    Result := Result + ';' + IntToStr(FreeShip.Layer[I].Color) + ';' +
      IntToStr(Ord(FreeShip.Layer[I].ShowInLinesplan)) + ';' +
      IntToStr(Ord(FreeShip.Layer[I].Symmetric));
end;

procedure TFreeLinesplanFrame.UpdateMenu;
begin
  ShowFillcolor.Enabled := not ShowMonochrome.Checked;
  UseLights.Enabled := (ShowFillcolor.Checked) and (not ShowMonochrome.Checked);
  MirrorPlanview.Enabled := Freeship.NumberofDiagonals = 0;
end;{TFreeLinesplanFrame.UpdateMenu}

procedure TFreeLinesplanFrame.FSetFreeShip(Val: TFreeShip);
begin
  if Val=FFreeShip then Exit;
  if FDiskFillDirty and (FFillVector<>nil) then FFillVector.SaveDisk(FDiskFillPath);
  // Transfer ownership, not pixels: keep the complete model-space fill and its
  // filtered levels across window lifetimes. Model invalidation discards it.
  if (FFreeShip<>nil) and not (csDestroying in FFreeShip.ComponentState) and
    (FFillVector<>nil) and FFillVector.Valid then begin
    FreeAndNil(FFreeShip.LinesplanFillCache);
    FFreeShip.LinesplanFillCache:=FFillVector;
    FFreeShip.LinesplanFillCacheKey:=FFillVectorKey;
    FFillVector:=nil;
  end;
  InvalidateRenderCache;
  if FFreeShip <> nil then
    FFreeShip.LinesplanFrame := nil;
  FFreeShip := Val;
  if FFreeShip <> nil then
  begin
    //USE ONCE!
    ///FFreeship.Preferences.dumpIcons(MenuImages,ActionList1);

    Freeship.Preferences.LoadImageListByActions(MenuImages, ActionList1);

    FFreeShip.LinesplanFrame := self;
    FFillVector:=TVectorFillCache(FFreeShip.LinesplanFillCache);
    FFillVectorKey:=FFreeShip.LinesplanFillCacheKey;
    FFreeShip.LinesplanFillCache:=nil;
    FFreeShip.LinesplanFillCacheKey:='';
    UpdateMenu;
  end;
end;{TFreeLinesplanFrame.FSetFreeShip}

procedure TFreeLinesplanFrame.ViewportRequestExtents(Sender: TObject;
  var Min, Max: T3DCoordinate);
var
  Space, Tmp: TFloatType;
  Min3D, Max3D: T3DCoordinate;
  P, Diff: T3DCoordinate;
  I, J, K: integer;
  Diagonal: TFreeIntersection;
  Spline: TFreeSpline;
  Plane: T3DPlane;
  First: boolean;
  Layer: TFreeSubdivisionLayer;
begin
  if Freeship <> nil then
  begin
    First := True;
    for I := 1 to Freeship.NumberOfLayers do
    begin
      Layer := Freeship.Layer[I - 1];
      if Layer.ShowInLinesplan then
      begin
        for J := 1 to Layer.Count do
        begin
          if First then
          begin
            Min3D := Layer.Items[J - 1].Min;
            Max3D := Min3D;
            First := False;
          end;
          MinMax(Layer.Items[J - 1].Min, Min3D, Max3D);
          MinMax(Layer.Items[J - 1].Max, Min3D, Max3D);
        end;
      end;
    end;
    for I := 1 to Freeship.NumberofStations do
      Freeship.Station[I - 1].Extents(Min3D, Max3D);
    for I := 1 to Freeship.NumberofButtocks do
      Freeship.Buttock[I - 1].Extents(Min3D, Max3D);
    for I := 1 to Freeship.NumberofWaterlines do
      Freeship.Waterline[I - 1].Extents(Min3D, Max3D);
    for I := 1 to Freeship.NumberofDiagonals do
      Freeship.Diagonal[I - 1].Extents(Min3D, Max3D);

    FMin3D := Min3D;
    FMax3D := Max3D;
    FModelHeight := Max3D.Z - Min3D.Z;
    FModelBeam := 2 * Max3D.Y;
    FModelLength := Max3D.X - Min3D.X;
    Space := SpacePercentage * FModelHeight;
    if 2 * FModelBeam + Space > FModelLength then
      FModelLength := 2 * FModelBeam + Space;
    FDiagonalWidth := 0;
    for I := 1 to Freeship.NumberofDiagonals do
    begin
      Diagonal := Freeship.Diagonal[I - 1];
      Plane.a := 0.0;
      Plane.b := 1 / Sqrt(2);
      Plane.c := -1 / sqrt(2);
      Plane.d := -Diagonal.Plane.d;
      if not Diagonal.Built then
        Diagonal.Rebuild;
      for J := 1 to Diagonal.Count do
      begin
        Spline := Diagonal.Items[J - 1];
        for k := 1 to Spline.NumberOfPoints do
        begin
          P := Spline.Point[K - 1];
          Tmp := abs(Plane.A * P.x + Plane.B * P.y + Plane.C * P.z + Plane.D);
          if Tmp > FDiagonalWidth then
            FDiagonalWidth := Tmp;
        end;
      end;
    end;

    Min.X := Min3D.X - 0.5 * space;
    // if no diagonals present in model, the mirror planview
    if Freeship.NumberofDiagonals > 0 then
      Min.Y := Min3D.Z - 2 * Space - FModelHeight - 0.5 * FModelBeam - 0.5 * space - space - FDiagonalWidth
    else
    if (Freeship.NumberofDiagonals = 0) and (MirrorPlanview.Checked) then
      Min.Y := Min3D.Z - 2 * Space - FModelHeight - FModelBeam - 0.5 * space
    else
      Min.Y := Min3D.Z - 2 * Space - FModelHeight - 0.5 * FModelBeam - 0.5 * space;

    Min.Z := 0.0;
    Max.X := Min.X + FModelLength + 0.5 * space;
    Max.Y := -Min3D.Z + FModelHeight + 0.5 * space;
    Max.Z := 0.0;
    Tmp := (FModelLength - 2 * FModelbeam - 3 * space) / 3;

    // Attachpoint for profileview
    FProfileOrigin.X := 0.0;
    FProfileOrigin.Y := -Min3D.Z;
    FProfileOrigin.Z := 0.0;
    // Attachpoint for aft view of bodyplan
    FAftOrigin.X := Min.X + Tmp + 0.5 * FModelbeam;
    FAftOrigin.Y := FProfileOrigin.Y - Space - FModelHeight;
    FAftOrigin.Z := 0.0;
    // Attachpoint for front view of bodyplan
    FFrontOrigin := FAftOrigin;
    FFrontOrigin.X := Max.X - Tmp - 0.5 * FModelbeam;
    // Attachpoint for plan view
    FPlanOrigin.X := FProfileOrigin.X;
    FPlanOrigin.Y := FAftOrigin.Y - space - 0.5 * FModelBeam + Min3D.Z;
    FPlanOrigin.Z := 0.0;

    // Blowup the boundary box by 3%
    Diff := ScalePoint(0.03, Subtract(Max3D, Min3D));
    Min := Subtract(Min, Diff);
    Diff := ScalePoint(-1.0, Diff);
    Max := Subtract(Max, diff);

  end
  else
  begin
    Min.X := -1;
    Min.Y := Min.X;
    Min.Z := Min.X;
    Max.X := -Min.X;
    Max.Y := Max.X;
    Max.Z := Max.X;
  end;
end;{TFreeLinesplanFrame.ViewportRequestExtents}

procedure TFreeLinesplanFrame.SpinEdit1Change(Sender: TObject);
begin
  FinishInteraction(nil);
  FFontSize := (Sender as TSpinEdit).Value;
  Viewport.invalidate;
end;

function TFreeLinesplanFrame.LabelBackgroundCost(const R: TRect): integer;
var X, Y, I: integer; C: TColor;
begin
  Result := 0;
  // Filled hull areas are already painted before the labels. Prefer local
  // candidates on a light background so dark text remains legible.
  for I := 0 to 4 do begin
    case I of
      0: begin X:=(R.Left+R.Right) div 2; Y:=(R.Top+R.Bottom) div 2 end;
      1: begin X:=R.Left+1; Y:=R.Top+1 end;
      2: begin X:=R.Right-2; Y:=R.Top+1 end;
      3: begin X:=R.Left+1; Y:=R.Bottom-2 end;
      else begin X:=R.Right-2; Y:=R.Bottom-2 end;
    end;
    C := ColorToRGB(Viewport.DrawingCanvas.Pixels[X,Y]);
    if (GetRValue(C)+GetGValue(C)+GetBValue(C)<390) then Inc(Result, 2);
  end;
end;

procedure TFreeLinesplanFrame.ViewportRedraw(Sender: TObject);
type
  TriangleData = record
    P1, P2, P3: T3DCoordinate;
    Center: T3DCoordinate;
    Color: TColor;
    Symmetric: boolean;
  end;

  TriangleArray = record
    Capacity: integer;
    Count: integer;
    Triangles: array of TriangleData;
  end;
var
  I, J, N, K, L: integer;
  Edge: TFreeSubdivisionEdge;
  Layer: TFreeSubdivisionLayer;
  Face: TFreeSubdivisionControlface;
  Child: TFreeSubdivisionFace;
  MidshipLocation: TFloatType;
  Tmp, Space: TFloatType;
  Min, Max: TFloatType;
  //ResFactor: TFloatType;
  //ScaleFactor: TFloatType;
  WlPlane: T3DPlane;
  MainPlane: T3DPlane;
  Plane: T3DPlane;
  Below: TriangleArray;
  Above: TriangleArray;
  Done: boolean;
  Diagonal: TFreeIntersection;
  Spline: TFreeSpline;
  P, P1, P2, Pkn: T3DCoordinate;
  Pts: array of TPoint;
  Pts3D: array of T3DCoordinate;
  //Pt: TPoint;
  Steps: integer;
  PenwidthFactor: integer;
  Str: string;
  Prevcursor: TCursor;
  SubmColor: TColor;
  Pn, Pn1,Pn2: integer;
  LabelIndex: integer;
  PaintStarted: QWord;
  CacheKey: string;
  LabelContextKey: string;
  CanCache: Boolean;
  UsingInteractionPreview: Boolean;
  BuildingAtlas, CaptureAtlas: Boolean;
  VectorRecording:Boolean;VectorSavedCanvas:TCanvas;
  AtlasZoom: TFloatType;
  AtlasPan: TPoint;
  KnuckleSegments: array of TSmoothSegment;
  KnuckleCount: Integer;
  PendingLabels:array of record X,Y,Outward,Index,FontSize:Integer;Text,FontName:string;Vertical:Boolean;Color:TColor end;


  procedure DrawLineLabel(X, Y: integer; const Text: string; Vertical: boolean; Outward: integer);
  var Placement: TLabelPlacement; Kind: TLabelKind;
  begin
    if Viewport.Printing then begin Viewport.TextOut(X, Y, Text); Exit end;
    Inc(LabelIndex);
    if (Text <> '') and (Text[1] in ['0'..'9', '-']) then
    begin
      if Vertical then Kind := lkVerticalTick else Kind := lkHorizontalTick;
    end
    else Kind := lkNamedLine;
    Placement := Viewport.LabelLayout.Place('lines:' + IntToStr(LabelIndex), Text,
      Point(X,Y), Point(X,Y), Viewport.TextWidth(Text), Viewport.TextHeight(Text), Kind, Outward);
    if Placement.Visible then
      Viewport.TextOutLabel(Placement,Text);
  end;

  procedure PlaceLineLabel(X,Y:Integer;const Text:string;Vertical:Boolean;Outward:Integer);
  var N:Integer;
  begin
    if Viewport.Printing then begin Viewport.TextOut(X,Y,Text);Exit end;
    N:=Length(PendingLabels);SetLength(PendingLabels,N+1);
    PendingLabels[N].X:=X;PendingLabels[N].Y:=Y;PendingLabels[N].Text:=Text;
    PendingLabels[N].Vertical:=Vertical;PendingLabels[N].Outward:=Outward;
    PendingLabels[N].Index:=N+1;PendingLabels[N].FontName:=Viewport.FontName;
    PendingLabels[N].FontSize:=Viewport.FontSize;PendingLabels[N].Color:=Viewport.FontColor;
  end;

  procedure DrawPendingLabels;
  var Pass,N:Integer;Numeric:Boolean;
  begin
    for Pass:=0 to 1 do for N:=0 to High(PendingLabels) do begin
      Numeric:=(PendingLabels[N].Text<>'') and (PendingLabels[N].Text[1] in ['0'..'9','-']);
      if (Pass=1)<>Numeric then Continue;
      Viewport.FontName:=PendingLabels[N].FontName;Viewport.FontSize:=PendingLabels[N].FontSize;
      Viewport.FontColor:=PendingLabels[N].Color;LabelIndex:=PendingLabels[N].Index-1;
      DrawLineLabel(PendingLabels[N].X,PendingLabels[N].Y,PendingLabels[N].Text,PendingLabels[N].Vertical,PendingLabels[N].Outward);
    end;
  end;

  // Register the projected feature edges which this view draws later.  The
  // label layout works in viewport pixels, not model or window coordinates.
  procedure CollectFeatureEdges;
  var I: integer; Edge: TFreeSubdivisionControlEdge; A, B, Q1, Q2: T3DCoordinate;
    procedure AddProjected(const P1, P2: T3DCoordinate);
    begin Viewport.LabelLayout.AddSegment(Viewport.Project(P1), Viewport.Project(P2)) end;
  begin
    if Viewport.Printing then Exit;
    for I := 0 to FreeShip.Surface.NumberOfControlEdges-1 do begin
      Edge := FreeShip.Surface.ControlEdge[I];
      if not (Edge.Visible and Edge.Crease) then Continue;
      A := Edge.StartPoint.Coordinate; B := Edge.EndPoint.Coordinate;
      Q1 := Point3D(FProfileOrigin.X+A.X, FProfileOrigin.Y+A.Z, 0);
      Q2 := Point3D(FProfileOrigin.X+B.X, FProfileOrigin.Y+B.Z, 0);
      AddProjected(Q1,Q2);
      Q1 := Point3D(FPlanOrigin.X+A.X, FPlanOrigin.Y+A.Y, 0);
      Q2 := Point3D(FPlanOrigin.X+B.X, FPlanOrigin.Y+B.Y, 0);
      AddProjected(Q1,Q2);
      if (FreeShip.NumberofDiagonals=0) and MirrorPlanview.Checked then begin
        Q1.Y := FPlanOrigin.Y-A.Y; Q2.Y := FPlanOrigin.Y-B.Y; AddProjected(Q1,Q2);
      end;
      if (A.X<=MidshipLocation) and (B.X<MidshipLocation) then begin
        Q1 := Point3D(FAftOrigin.X-A.Y, FAftOrigin.Y+A.Z, 0);
        Q2 := Point3D(FAftOrigin.X-B.Y, FAftOrigin.Y+B.Z, 0); AddProjected(Q1,Q2);
        Q1.X := FAftOrigin.X+A.Y; Q2.X := FAftOrigin.X+B.Y; AddProjected(Q1,Q2);
      end;
      if (A.X>=MidshipLocation) and (B.X>MidshipLocation) then begin
        Q1 := Point3D(FFrontOrigin.X-A.Y, FFrontOrigin.Y+A.Z, 0);
        Q2 := Point3D(FFrontOrigin.X-B.Y, FFrontOrigin.Y+B.Z, 0); AddProjected(Q1,Q2);
        Q1.X := FFrontOrigin.X+A.Y; Q2.X := FFrontOrigin.X+B.Y; AddProjected(Q1,Q2);
      end;
    end;
  end;

  procedure DrawLineAtt(Attachpoint, P1, P2: T3DCoordinate; Text: string; CenterText: boolean);
  var
    Proj1: T3DCoordinate;
    Proj2: T3DCoordinate;
    Pts: array[0..1] of TPoint;
    W: integer;
  begin
    Proj1.X := Attachpoint.X + P1.X;
    Proj1.Y := Attachpoint.Y + P1.Y;
    Proj1.Z := 0.0;
    Pts[0] := Viewport.Project(Proj1);
    Proj2.X := Attachpoint.X + P2.X;
    Proj2.Y := Attachpoint.Y + P2.Y;
    Proj2.Z := 0.0;
    Pts[1] := Viewport.Project(Proj2);
    Viewport.Polyline(Pts);
    if Text <> '' then
    begin
      if (CenterText) and (Pts[0].X = Pts[1].X) then
      begin
        W := Viewport.TextWidth(Text) div 2;
        PlaceLineLabel(Pts[0].X - W, Pts[0].Y, Text, Pts[0].X = Pts[1].X, Sign(Pts[0].Y - Pts[1].Y));
        PlaceLineLabel(Pts[1].X - W, Pts[1].Y, Text, Pts[0].X = Pts[1].X, Sign(Pts[1].Y - Pts[0].Y));
      end
      else
      begin
        W := 0;
        PlaceLineLabel(Pts[1].X - W, Pts[0].Y, Text, Pts[0].X = Pts[1].X, Sign(Pts[1].X - Pts[0].X));
        if (Pts[0].Y = Pts[1].Y) and (Pts[1].X <> Pts[0].X) then
          W := Viewport.TextWidth(Text)
        else
          W := 0;
        PlaceLineLabel(Pts[0].X - W, Pts[1].Y, Text, Pts[0].X = Pts[1].X, Sign(Pts[0].X - Pts[1].X));
      end;
    end;
  end;{DrawLineAtt}

  procedure DrawDiagonalLine(Origin: T3DCoordinate; P1, P2: T3DCoordinate);
  var
    Pt: TPoint;
    P: T3DCoordinate;
  begin
    P.X := Origin.X + P1.Y;
    P.Y := Origin.Y + P1.Z;
    P.Z := 0.0;
    Pt := Viewport.Project(P);
    Viewport.MoveTo(Pt.X, Pt.Y);
    P.X := Origin.X + P2.Y;
    P.Y := Origin.Y + P2.Z;
    Pt := Viewport.Project(P);
    Viewport.LineTo(Pt.X, Pt.Y);
    P.X := Origin.X - P1.Y;
    P.Y := Origin.Y + P1.Z;
    Pt := Viewport.Project(P);
    Viewport.MoveTo(Pt.X, Pt.Y);
    P.X := Origin.X - P2.Y;
    P.Y := Origin.Y + P2.Z;
    Pt := Viewport.Project(P);
    Viewport.LineTo(Pt.X, Pt.Y);
  end;{DrawDiagonalLine}

  procedure QueueKnuckle(const A,B:TPoint);
  begin
    if KnuckleCount=Length(KnuckleSegments) then SetLength(KnuckleSegments,KnuckleCount+1024);
    KnuckleSegments[KnuckleCount].A.X:=A.X;KnuckleSegments[KnuckleCount].A.Y:=A.Y;
    KnuckleSegments[KnuckleCount].B.X:=B.X;KnuckleSegments[KnuckleCount].B.Y:=B.Y;
    Inc(KnuckleCount);
  end;
  procedure FlushKnuckles;
  var N:Integer; Points:array[0..1] of TPoint;
  begin
    SetLength(KnuckleSegments,KnuckleCount);
    if KnuckleCount=0 then Exit;
    if not Viewport.Printing then
      if DrawSmoothSegments(Viewport.DrawingCanvas,KnuckleSegments) then Exit;
    for N:=0 to KnuckleCount-1 do begin
      Points[0]:=Point(Round(KnuckleSegments[N].A.X),Round(KnuckleSegments[N].A.Y));
      Points[1]:=Point(Round(KnuckleSegments[N].B.X),Round(KnuckleSegments[N].B.Y));
      Viewport.Polyline(Points);
    end;
  end;

  procedure DrawLine(P1, P2: T3DCoordinate);
  var
    Proj1: T3DCoordinate;
    Proj2: T3DCoordinate;
    Pts: array[0..1] of TPoint;
  begin
    // Draw in profileview
    Proj1.X := FProfileOrigin.X + P1.X;
    Proj1.Y := FProfileOrigin.Y + P1.Z;
    Proj1.Z := 0.0;
    Pts[0] := Viewport.Project(Proj1);
    Proj2.X := FProfileOrigin.X + P2.X;
    Proj2.Y := FProfileOrigin.Y + P2.Z;
    Proj2.Z := 0.0;
    Pts[1] := Viewport.Project(Proj2);
    QueueKnuckle(Pts[0],Pts[1]);

    // Draw in aft view of bodyplan
    if (P1.X <= MidshipLocation) and (P2.X < MidshipLocation) then
    begin
      Proj1.X := FAftOrigin.X - P1.Y;
      Proj1.Y := FAftOrigin.Y + P1.Z;
      Pts[0] := Viewport.Project(Proj1);
      Proj2.X := FAftOrigin.X - P2.Y;
      Proj2.Y := FAftOrigin.Y + P2.Z;
      Pts[1] := Viewport.Project(Proj2);
      QueueKnuckle(Pts[0],Pts[1]);
      Proj1.X := FAftOrigin.X + P1.Y;
      Proj1.Y := FAftOrigin.Y + P1.Z;
      Pts[0] := Viewport.Project(Proj1);
      Proj2.X := FAftOrigin.X + P2.Y;
      Proj2.Y := FAftOrigin.Y + P2.Z;
      Pts[1] := Viewport.Project(Proj2);
      QueueKnuckle(Pts[0],Pts[1]);
    end;

    // Draw in front view of bodyplan
    if (P1.X >= MidshipLocation) and (P2.X > MidshipLocation) then
    begin
      Proj1.X := FFrontOrigin.X - P1.Y;
      Proj1.Y := FFrontOrigin.Y + P1.Z;
      Pts[0] := Viewport.Project(Proj1);
      Proj2.X := FFrontOrigin.X - P2.Y;
      Proj2.Y := FFrontOrigin.Y + P2.Z;
      Pts[1] := Viewport.Project(Proj2);
      QueueKnuckle(Pts[0],Pts[1]);
      Proj1.X := FFrontOrigin.X + P1.Y;
      Proj1.Y := FFrontOrigin.Y + P1.Z;
      Pts[0] := Viewport.Project(Proj1);
      Proj2.X := FFrontOrigin.X + P2.Y;
      Proj2.Y := FFrontOrigin.Y + P2.Z;
      Pts[1] := Viewport.Project(Proj2);
      QueueKnuckle(Pts[0],Pts[1]);
    end;
    // Draw in plan view
    Proj1.X := FPlanOrigin.X + P1.X;
    Proj1.Y := FPlanOrigin.Y + P1.Y;
    Pts[0] := Viewport.Project(Proj1);
    Proj2.X := FPlanOrigin.X + P2.X;
    Proj2.Y := FPlanOrigin.Y + P2.Y;
    Pts[1] := Viewport.Project(Proj2);
    QueueKnuckle(Pts[0],Pts[1]);
    if (Freeship.NumberofDiagonals = 0) and (MirrorPlanview.Checked) then
    begin
      Proj1.X := FPlanOrigin.X + P1.X;
      Proj1.Y := FPlanOrigin.Y - P1.Y;
      Pts[0] := Viewport.Project(Proj1);
      Proj2.X := FPlanOrigin.X + P2.X;
      Proj2.Y := FPlanOrigin.Y - P2.Y;
      Pts[1] := Viewport.Project(Proj2);
      QueueKnuckle(Pts[0],Pts[1]);
    end;
  end;{DrawLine}

  {$ifdef NOUSE}
  procedure DrawSpline(Spline: TFreeSpline; Views: TLinesplanViews; Style: TPenStyle);
  var
    I,J,L: integer;
    Pn,Pn1,Pn2:integer;
    P, Pr, Pkn: T3DCoordinate;
    Pts: array of TPoint;
    YSign:integer;
  begin
    Setlength(Pts, Steps + 1 + Spline.NumberOfPoints);
    Viewport.PenStyle := Style;

    if lvProfile in views then
    begin
      Pn:=0; J:=0;
      for I := 0 to steps do
      begin
        P := Spline.Value(I / steps, Pn1, Pn2);
        // if the current step entered next rib and the Pn1 of it is knuckle
        if (Pn <> Pn1) and Spline.Knuckle[Pn1] then // add knuckle
        begin
          Pkn := Spline.Point[Pn1];
          Pr := Point3D(FProfileOrigin.X + Pkn.X, FProfileOrigin.Y + Pkn.Z, 0);
          Pts[J] := Viewport.Project(Pr);
          Pn:=Pn1;
          inc(J);
        end;
        Pr := Point3D(FProfileOrigin.X + P.X, FProfileOrigin.Y + P.Z, 0);
        Pts[J] := Viewport.Project(Pr);
        inc(J);
      end;
      Setlength(Pts, J);
      Viewport.Polyline(Pts);
    end;

    if (lvAftBody in views) and (Spline.Max.X <= MainFrame) then
    begin
      for YSign:=-1 to +1 do
        if YSign <> 0 then
        begin
          Pn:=0; J:=0;
          for I := 0 to steps do
          begin
            P := Spline.Value(I / steps, Pn1, Pn2);
            if (Pn <> Pn1) and Spline.Knuckle[Pn1] then
            begin
              // add knuckle
              Pkn := Spline.Point[Pn1];
              Pr := Point3D(FAftOrigin.X + YSign * Pkn.Y, FAftOrigin.Y + Pkn.Z, 0);
              Pts[J] := Viewport.Project(Pr);
              Pn:=Pn1;
              inc(J);
            end;
            Pr := Point3D(FAftOrigin.X + YSign * P.Y, FAftOrigin.Y + P.Z, 0);
            Pts[J] := Viewport.Project(Pr);
            inc(J);
          end;
          Setlength(Pts, J);
          Viewport.Polyline(Pts);
        end;
    end;

    if (lvFrontBody in views) and (Spline.Min.X >= MainFrame) then
    begin
      for YSign:=-1 to +1 do
        if YSign <> 0 then
        begin
          Pn:=0; J:=0;
          for I := 0 to steps do
          begin
            P := Spline.Value(I / steps, Pn1, Pn2);
            if (Pn <> Pn1) and Spline.Knuckle[Pn1] then
            begin
              // add knuckle
              Pkn := Spline.Point[Pn1];
              Pr := Point3D(FFrontOrigin.X + YSign * Pkn.Y, FFrontOrigin.Y + Pkn.Z, 0);
              Pts[J] := Viewport.Project(Pr);
              Pn:=Pn1;
              inc(J);
            end;
            Pr := Point3D(FFrontOrigin.X + YSign * P.Y, FFrontOrigin.Y + P.Z, 0);
            Pts[J] := Viewport.Project(Pr);
            inc(J);
          end;
          Setlength(Pts, J);
          Viewport.Polyline(Pts);
        end;
    end;

    if lvPLan in views then
    begin
      for YSign:=-1 to +1 do
        if (YSign=1)
          or ((YSign=0) and (Freeship.NumberofDiagonals = 0)
             and (MirrorPlanview.Checked))
        then
        begin
          Pn:=0; J:=0;
          for I := 0 to steps do
          begin
            P := Spline.Value(I / steps, Pn1, Pn2);
            if (Pn <> Pn1) and Spline.Knuckle[Pn1] then
            begin
              // add knuckle
              Pkn := Spline.Point[Pn1];
              Pr := Point3D(FPlanOrigin.X + YSign * Pkn.Y, FPlanOrigin.Y + Pkn.Y, 0);
              Pr.Z := 0.0;
              Pts[J] := Viewport.Project(Pr);
              Pn:=Pn1;
              inc(J);
            end;
            Pr := Point3D(FPlanOrigin.X + YSign * P.Y, FPlanOrigin.Y + P.Y, 0);
            Pts[J] := Viewport.Project(Pr);
            inc(J);
          end;
          Setlength(Pts, J);
          Viewport.Polyline(Pts);
        end;
    end;

  end;{DrawSpline}
  {$endif NOUSE}

  procedure DrawSpline(Spline: TFreeSpline; Views: TLinesplanViews; Style: TPenStyle);
  var
    i: integer;
    P, Pr: T3DCoordinate;
    VPs: array of T3DCoordinate;
    Pts: array of TPoint;
    YSign:integer;
  begin
    VPs := Spline.GetValues;
    Setlength(Pts, length(VPs));
    if lvProfile in views then
    begin
      for i := 0 to length(VPs)-1 do
        begin
          P := VPs[i];
          Pr := Point3D(FProfileOrigin.X + P.X, FProfileOrigin.Y + P.Z, 0);
          Pts[i] := Viewport.Project(Pr);
        end;
      Viewport.Polyline(Pts);
    end;

    if (lvAftBody in views) and (Spline.Max.X <= MidshipLocation) then
    begin
      for YSign:=-1 to +1 do
        if YSign <> 0 then
        begin
          for i := 0 to length(VPs)-1 do
            begin
              P := VPs[i];
              Pr := Point3D(FAftOrigin.X + YSign * P.Y, FAftOrigin.Y + P.Z, 0);
              Pts[i] := Viewport.Project(Pr);
            end;
          Viewport.Polyline(Pts);
        end;
    end;

    if (lvFrontBody in views) and (Spline.Min.X >= MidshipLocation) then
    begin
      for YSign:=-1 to +1 do
        if YSign <> 0 then
        begin
          for i := 0 to length(VPs)-1 do
            begin
              P := VPs[i];
              Pr := Point3D(FFrontOrigin.X + YSign * P.Y, FFrontOrigin.Y + P.Z, 0);
              Pts[i] := Viewport.Project(Pr);
            end;
          Viewport.Polyline(Pts);
        end;
    end;

    if lvPLan in views then
    begin
      for YSign:=-1 to +1 do
        if (YSign=1)
          or ((YSign=0) and (Freeship.NumberofDiagonals = 0)
             and (MirrorPlanview.Checked))
        then
        begin
          for i := 0 to length(VPs)-1 do
            begin
              P := VPs[i];
              Pr := Point3D(FPlanOrigin.X + YSign * P.Y, FPlanOrigin.Y + P.Y, 0);
              Pts[i] := Viewport.Project(Pr);
            end;
          Viewport.Polyline(Pts);
        end;
    end;

  end;{DrawSpline}


  procedure DrawIntersection(Intersection: TFreeIntersection;
    Views: TLinesplanViews; Style: TPenStyle);
  var
    I: integer;
  begin
    if not Intersection.Built then
      Intersection.Rebuild;
    for I := 1 to Intersection.Count do
      DrawSpline(Intersection.Items[I - 1], Views, Style);
  end;{DrawIntersection}

  procedure AddTriangle(P1, P2, P3: T3DCoordinate; Color: TColor;
  var Destination: TriangleArray; Symmetric: boolean);
  var
    C: T3DCoordinate;
  begin
    if Destination.Count = Destination.Capacity then
    begin
      Destination.Capacity := Math.Max(64, Destination.Capacity * 2);
      Setlength(Destination.Triangles, Destination.Capacity);
    end;
    C.X := (P1.X + P2.X + P3.X) / 3;
    C.Y := (P1.Y + P2.Y + P3.Y) / 3;
    C.Z := (P1.Z + P2.Z + P3.Z) / 3;
    Destination.Triangles[Destination.Count].P1 := P1;
    Destination.Triangles[Destination.Count].P2 := P2;
    Destination.Triangles[Destination.Count].P3 := P3;
    Destination.Triangles[Destination.Count].Center := C;
    Destination.Triangles[Destination.Count].Color := Color;
    Destination.Triangles[Destination.Count].Symmetric := Symmetric;
    Inc(Destination.Count);
  end;{AddTriangle}

  procedure ProcessFace(Face: TFreeSubdivisionFace; Color: TColor; Symmetric: boolean);
  var
    I, J: integer;
    Nabove: integer;
    Nbelow: integer;
    AbovePoints: TFreeCoordinateArray;
    BelowPoints: TFreeCoordinateArray;
  begin
    for I := 3 to Face.NumberOfpoints do
    begin
      ClipTriangle(Face.Point[0].Coordinate,
        Face.Point[I - 2].Coordinate,
        Face.Point[I - 1].Coordinate,
        WlPlane, Nabove, Nbelow, AbovePoints, BelowPoints);
      // proces submerged area
      for J := 3 to NBelow do
        AddTriangle(BelowPoints[0], BelowPoints[J - 2], BelowPoints[J - 1], SubmColor, Below, Symmetric);
      for J := 3 to NAbove do
        AddTriangle(AbovePoints[0], AbovePoints[J - 2], AbovePoints[J - 1], Color, Above, Symmetric);
    end;
  end;{Processface}

  procedure SortTriangles(var Triangles: TriangleArray; SortType: byte);
  // Sorttype 1=X, 2=Y, 3=Z

    procedure QuickSort(L, R: integer);
    var
      I, J: integer;
      T1: TriangleData;

      procedure Swap(I, J: integer);
      var
        Tmp: TriangleData;
      begin
        Tmp := Triangles.Triangles[I];
        Triangles.Triangles[I] := Triangles.Triangles[J];
        Triangles.Triangles[J] := Tmp;
      end;{swap two triangles}

    begin
      I := L;
      J := R;
      T1 := Triangles.Triangles[(L + R) div 2];
      repeat
        if SortType = 1 then
        begin
          while Triangles.Triangles[I].Center.X < T1.Center.X do
            Inc(I);
          while T1.Center.X < Triangles.Triangles[J].Center.X do
            Dec(J);
        end
        else if SortType = 2 then
        begin
          while Triangles.Triangles[I].Center.Y < T1.Center.Y do
            Inc(I);
          while T1.Center.Y < Triangles.Triangles[J].Center.Y do
            Dec(J);
        end
        else
        begin
          while Triangles.Triangles[I].Center.Z < T1.Center.Z do
            Inc(I);
          while T1.Center.Z < Triangles.Triangles[J].Center.Z do
            Dec(J);
        end;
        if I <= J then
        begin
          Swap(I, J);
          Inc(I);
          Dec(J);
        end;
      until I > J;
      if L < J then
        QuickSort(L, J);
      if I < R then
        QuickSort(I, R);
    end;{QuickSort}

  begin
    if Triangles.Count > 1 then
      QuickSort(0, Triangles.Count - 1);
  end;{SortTriangles}

  procedure DrawTriangles(Triangles: TriangleArray; Views: TLinesplanViews);
  var
    I: integer;
    Triangle: TriangleData;
    Pts: array[0..2] of TPoint;
    P: T3DCoordinate;
    L: T3DCoordinate;
    Col: TColor;

    procedure SetFillColor(Color:TColor);
    begin
      Col:=Color;
      // Recording submits its own cached GDI paint objects. Updating the LCL
      // canvas here would create redundant pen/brush state for every triangle.
      if not VectorRecording then begin
        Viewport.BrushColor:=Color;Viewport.PenColor:=Color;
      end;
    end;

    function ProjectFillPoint(const P:T3DCoordinate):TPoint;
    begin
      if VectorRecording then Result:=FFillVector.Project(P.X,P.Y)
      else Result:=Viewport.Project(P);
    end;

    function GetColor(Lightvector: T3DCoordinate; DpScale, Contrast: TFloatType;
      Triangle: TriangleData): TColor;
    var
      N: T3DCoordinate;
      Dp: TFloatType;
      R, G, B: byte;
    begin
      N := UnifiedNormal(Triangle.P1, Triangle.P2, Triangle.P3);
      Dp := DotProduct(N, L);
      if Dp < 0.0 then
        Dp := -Dp;

      Dp := Power(Dp, Contrast);
      Dp := (DpScale - 1.0) + DpScale * Dp;
      if Dp > 1.0 then
        Dp := 1.0;
      R := Round(Dp * GetRValue(Triangle.Color));
      G := Round(Dp * GetGValue(Triangle.Color));
      B := Round(Dp * GetBValue(Triangle.Color));
      Result := RGB(R, G, B);
          {
          Viewport.ShadedColor(Dp,GetRValue(Triangle.Color),GetGValue(Triangle.Color),GetBValue(Triangle.Color),R,G,B);
          Result:=RGB(R,G,B);
          }
    end;{GetColor}

  begin
    if lvAftBody in views then
    begin
      P.Z := 0.0;
      L := SetPoint(-1.0, 0.0, 0.0);
      for I := Triangles.Count downto 1 do
      begin
        Triangle := Triangles.Triangles[I - 1];
        if not UseLights.Checked then
        begin
          SetFillColor(Triangle.Color);
        end
        else
        begin
          Col := GetColor(L, 1.4, 1.0, Triangle);
          SetFillColor(Col);
        end;
        // Draw in aft view
        P.X := FAftOrigin.X - Triangle.P1.Y;
        P.Y := FAftOrigin.Y + Triangle.P1.Z;
        Pts[0] := ProjectFillPoint(P);
        P.X := FAftOrigin.X - Triangle.P2.Y;
        P.Y := FAftOrigin.Y + Triangle.P2.Z;
        Pts[1] := ProjectFillPoint(P);
        P.X := FAftOrigin.X - Triangle.P3.Y;
        P.Y := FAftOrigin.Y + Triangle.P3.Z;
        Pts[2] := ProjectFillPoint(P);
        if VectorRecording then FFillVector.Polygon(Pts,Col)
        else Viewport.Polygon(Pts);
        if Triangle.Symmetric then
        begin
          P.X := FAftOrigin.X + Triangle.P1.Y;
          P.Y := FAftOrigin.Y + Triangle.P1.Z;
          Pts[0] := ProjectFillPoint(P);
          P.X := FAftOrigin.X + Triangle.P2.Y;
          P.Y := FAftOrigin.Y + Triangle.P2.Z;
          Pts[1] := ProjectFillPoint(P);
          P.X := FAftOrigin.X + Triangle.P3.Y;
          P.Y := FAftOrigin.Y + Triangle.P3.Z;
          Pts[2] := ProjectFillPoint(P);
          if VectorRecording then FFillVector.Polygon(Pts,Col)
        else Viewport.Polygon(Pts);
        end;
      end;
    end
    else
    begin
      L := SetPoint(-1.0, 0.0, 0.0);
      for I := 1 to Triangles.Count do
      begin
        Triangle := Triangles.Triangles[I - 1];
        P.Z := 0.0;
        if lvProfile in Views then
        begin
          L := SetPoint(0.0, -1.0, 0.0);
          if not UseLights.Checked then
          begin
            SetFillColor(Triangle.Color);
          end
          else
          begin
            Col := GetColor(L, 1.1, 1.5, Triangle);
            SetFillColor(Col);
          end;
          // Draw in profile view
          P.X := FProfileOrigin.X + Triangle.P1.X;
          P.Y := FProfileOrigin.Y + Triangle.P1.Z;
          Pts[0] := ProjectFillPoint(P);
          P.X := FProfileOrigin.X + Triangle.P2.X;
          P.Y := FProfileOrigin.Y + Triangle.P2.Z;
          Pts[1] := ProjectFillPoint(P);
          P.X := FProfileOrigin.X + Triangle.P3.X;
          P.Y := FProfileOrigin.Y + Triangle.P3.Z;
          Pts[2] := ProjectFillPoint(P);
          if VectorRecording then FFillVector.Polygon(Pts,Col)
        else Viewport.Polygon(Pts);
        end;

        if lvFrontBody in views then
        begin
          L := SetPoint(1.0, 0.0, 0.0);
          if not UseLights.Checked then
          begin
            SetFillColor(Triangle.Color);
          end
          else
          begin
            Col := GetColor(L, 1.4, 1.0, Triangle);
            SetFillColor(Col);
          end;
          // Draw in Front view
          P.X := FFrontOrigin.X - Triangle.P1.Y;
          P.Y := FFrontOrigin.Y + Triangle.P1.Z;
          Pts[0] := ProjectFillPoint(P);
          P.X := FFrontOrigin.X - Triangle.P2.Y;
          P.Y := FFrontOrigin.Y + Triangle.P2.Z;
          Pts[1] := ProjectFillPoint(P);
          P.X := FFrontOrigin.X - Triangle.P3.Y;
          P.Y := FFrontOrigin.Y + Triangle.P3.Z;
          Pts[2] := ProjectFillPoint(P);
          if VectorRecording then FFillVector.Polygon(Pts,Col)
        else Viewport.Polygon(Pts);
          if Triangle.Symmetric then
          begin
            P.X := FFrontOrigin.X + Triangle.P1.Y;
            P.Y := FFrontOrigin.Y + Triangle.P1.Z;
            Pts[0] := ProjectFillPoint(P);
            P.X := FFrontOrigin.X + Triangle.P2.Y;
            P.Y := FFrontOrigin.Y + Triangle.P2.Z;
            Pts[1] := ProjectFillPoint(P);
            P.X := FFrontOrigin.X + Triangle.P3.Y;
            P.Y := FFrontOrigin.Y + Triangle.P3.Z;
            Pts[2] := ProjectFillPoint(P);
            if VectorRecording then FFillVector.Polygon(Pts,Col)
        else Viewport.Polygon(Pts);
          end;
        end;
        if lvPlan in views then
        begin
          L := SetPoint(0.0, 0.0, -1.0);
          if not UseLights.Checked then
          begin
            SetFillColor(Triangle.Color);
          end
          else
          begin
            Col := GetColor(L, 1.1, 1.5, Triangle);
            SetFillColor(Col);
          end;
          // Draw portside in plan view
          P.X := FPlanOrigin.X + Triangle.P1.X;
          P.Y := FPlanOrigin.Y + Triangle.P1.Y;
          Pts[0] := ProjectFillPoint(P);
          P.X := FPlanOrigin.X + Triangle.P2.X;
          P.Y := FPlanOrigin.Y + Triangle.P2.Y;
          Pts[1] := ProjectFillPoint(P);
          P.X := FPlanOrigin.X + Triangle.P3.X;
          P.Y := FPlanOrigin.Y + Triangle.P3.Y;
          Pts[2] := ProjectFillPoint(P);
          if VectorRecording then FFillVector.Polygon(Pts,Col)
        else Viewport.Polygon(Pts);
          if (Freeship.NumberofDiagonals = 0) and (MirrorPlanview.Checked) and
            (Triangle.Symmetric) then
          begin
            P.X := FPlanOrigin.X + Triangle.P1.X;
            P.Y := FPlanOrigin.Y - Triangle.P1.Y;
            Pts[0] := ProjectFillPoint(P);
            P.X := FPlanOrigin.X + Triangle.P2.X;
            P.Y := FPlanOrigin.Y - Triangle.P2.Y;
            Pts[1] := ProjectFillPoint(P);
            P.X := FPlanOrigin.X + Triangle.P3.X;
            P.Y := FPlanOrigin.Y - Triangle.P3.Y;
            Pts[2] := ProjectFillPoint(P);
            if VectorRecording then FFillVector.Polygon(Pts,Col)
        else Viewport.Polygon(Pts);
          end;
        end;
      end;
    end;
  end;{DrawTriangles}

  procedure PrepareFillAtlas;
  var Min,Max:T3DCoordinate; A,B,SavedPan:TPoint; SavedZoom:TFloatType;
  begin
    {$IFDEF MSWINDOWS}
    if CanCache then begin
      if FFillVector=nil then FFillVector:=TVectorFillCache.Create;
      Min:=Viewport.Min3D;Max:=Viewport.Max3D;
      VectorRecording:=FFillVector.BeginRecord(Viewport.DrawingCanvas,Min.X,Min.Y,Max.X,Max.Y,Viewport.Color);
      if VectorRecording then begin
        VectorSavedCanvas:=Viewport.DrawingCanvas;Viewport.DrawingCanvas:=FFillVector.Canvas;
      end;
    end;
    Exit;
    {$ENDIF}
    BuildingAtlas := CanCache and ((FInteractionImage=nil) or
      (FInteractionKey<>FillCacheKey(False)));
    if not BuildingAtlas then Exit;
    Min:=Viewport.Min3D; Max:=Viewport.Max3D;
    A:=Viewport.Project(Min); B:=Viewport.Project(Max);
    if (Math.Min(A.X,B.X)>=0) and (Math.Min(A.Y,B.Y)>=0) and
       (Math.Max(A.X,B.X)<Viewport.ClientWidth) and (Math.Max(A.Y,B.Y)<Viewport.ClientHeight) then
    begin
      // A fitted view already contains the entire hull. Capture it once,
      // without drawing all triangles a second time just to build the atlas.
      CaptureAtlas:=True; BuildingAtlas:=False;
      FInteractionOrigin:=Viewport.Project(ZERO);
      FInteractionScale:=Viewport.Scale*Viewport.Zoom;
      Exit;
    end;
    SavedZoom:=Viewport.Zoom; SavedPan:=Viewport.Pan;
    try
      Viewport.Zoom:=Math.Min(1.0,SavedZoom*Math.Min((Viewport.ClientWidth-8)/Math.Max(1,Abs(B.X-A.X)),
        (Viewport.ClientHeight-8)/Math.Max(1,Abs(B.Y-A.Y))));
      AtlasZoom:=Viewport.Zoom;
      Viewport.Pan:=Point(0,0); A:=Viewport.Project(Min); B:=Viewport.Project(Max);
      AtlasPan:=Point(4-Math.Min(A.X,B.X),4-Math.Min(A.Y,B.Y));
      Viewport.Pan:=AtlasPan;
      FInteractionOrigin:=Viewport.Project(ZERO);
      FInteractionScale:=Viewport.Scale*AtlasZoom;
      if FInteractionImage=nil then FInteractionImage:=TBitmap.Create;
      FInteractionImage.SetSize(Viewport.ClientWidth,Viewport.ClientHeight);
      FInteractionImage.Canvas.Brush.Color:=Viewport.Color;
      FInteractionImage.Canvas.FillRect(Rect(0,0,FInteractionImage.Width,FInteractionImage.Height));
      FInteractionImage.Canvas.Brush.Style:=bsSolid;
      FInteractionImage.Canvas.Pen.Width:=1;
    finally
      Viewport.Zoom:=SavedZoom; Viewport.Pan:=SavedPan;
    end;
  end;

  procedure DrawFillTriangles(Triangles:TriangleArray; Views:TLinesplanViews);
  var SavedCanvas:TCanvas; SavedPan:TPoint; SavedZoom:TFloatType;
  begin
    DrawTriangles(Triangles,Views);
    if not BuildingAtlas then Exit;
    SavedCanvas:=Viewport.DrawingCanvas; SavedPan:=Viewport.Pan; SavedZoom:=Viewport.Zoom;
    try
      Viewport.DrawingCanvas:=FInteractionImage.Canvas;
      Viewport.Zoom:=AtlasZoom; Viewport.Pan:=AtlasPan;
      DrawTriangles(Triangles,Views);
    finally
      Viewport.DrawingCanvas:=SavedCanvas;
      Viewport.Zoom:=SavedZoom; Viewport.Pan:=SavedPan;
    end;
  end;

  procedure SetFontHeight(DesiredHeight: TFloatType);
  var
    Height: integer;
    CurrentHeight: integer;
  begin
    // Sets the fontheight to a height in modelspace
    Height := round(DesiredHeight * Viewport.Scale * Viewport.Zoom);
    CurrentHeight := Viewport.FontHeight;
    if CurrentHeight <> Height then
      Viewport.FontHeight := Height;

    // below code causes loop redraw and 100% CPU.
    // Changed to above code with direct set of required Font.Height
      {Height:=DesiredHeight*Viewport.Scale*Viewport.Zoom;
      Viewport.Font.Size:=8;
      CurrentHeight:=Viewport.TextHeight('X');
      while CurrentHeight>Height do
      begin
         Viewport.Font.Size:=Viewport.Font.Size-1;
         CurrentHeight:=Viewport.TextHeight('X');
         if Viewport.Font.Size<6 then break;
      end;}
  end;{SetFontHeight}

begin
  if Freeship = nil then
    exit;
  PaintStarted := GetTickCount64;
  BuildingAtlas := False;
  CaptureAtlas := False;
  VectorRecording:=False;
  KnuckleCount := 0;
  UsingInteractionPreview := DrawInteractionPreview;
  LabelIndex := 0;
  if Viewport.ExportingBitmap then Viewport.LabelLayout.Clear;
  Viewport.SyncLabelHistory;
  LabelContextKey:=FillCacheKey(False)+';font='+IntToStr(FFontSize)+
    ';fill='+IntToStr(Ord(ShowFillColor.Checked))+';mono='+IntToStr(Ord(ShowMonochrome.Checked));
  Viewport.LabelLayout.TranslationOnly:=FInteractionDragging and FPanDragStarted and
    not Viewport.Printing and not Viewport.ExportingBitmap and
    (FLastLabelContext=LabelContextKey) and
    (FLastLabelScale=Viewport.Scale*Viewport.Zoom);
  Viewport.LabelLayout.BeginFrame(Rect(0, 0, Viewport.ClientWidth, Viewport.ClientHeight),
    'lines:' + Freeship.Filename);
  if not Viewport.Printing then Viewport.LabelLayout.ExtraCost := LabelBackgroundCost;
  if Viewport.Printing then
    PenWidthfactor := Round(Viewport.PrintScaleFactor)
  else
    PenwidthFactor := 1;
  if Viewport.Printing then
    Steps := 1250
  else
    Steps := 200;
  WlPlane.a := 0.0;
  WlPlane.b := 0.0;
  WlPlane.c := 1.0;
  WlPlane.d := -(Freeship.Surface.Min.Z + Freeship.ProjectSettings.ProjectDraft);
  //MidshipLocation := Freeship.ProjectSettings.ProjectSplitSectionLocation;
  if not FFreeship.HydrostaticCalculation[0].Calculated then
    FFreeship.HydrostaticCalculation[0].Calculate;
  MidshipLocation := //FFreeship.ProjectSettings.ProjectSplitSectionLocation;
                     FFreeship.HydrostaticCalculation[0].MidshipLocation;
  Mainplane.a := 1.0;
  Mainplane.b := 0.0;
  Mainplane.c := 0.0;
  Mainplane.d := -MidshipLocation;

  Viewport.BrushStyle := bsSolid;
  Below.Count := 0;
  Below.Capacity := 0;
  Above.Count := 0;
  Above.Capacity := 0;
  Prevcursor := Screen.Cursor;
  if Viewport.Printing or Viewport.ExportingBitmap then Screen.Cursor := crHourglass;
  Viewport.PenColor := clSilver;

  Viewport.FontName := 'Arial';
  Viewport.FontColor := clBlack;
  // calculate and set fontheight
  //SetFontHeight(DistPP3D(FMin3D,FMax3D)/FontheightFactor * FFontheightScale);
  //just set font from the frame self
  //Viewport.FontName := Font.Name;
  //Viewport.FontColor := Font.Color;
  //Viewport.FontHeight:=Font.Height;
  //Viewport.FontSize := Font.Size;
  if Viewport.DrawingCanvas.Font = nil then
     Viewport.DrawingCanvas.Font := TFont.Create;
  Viewport.DrawingCanvas.Font.Name := 'Arial';
  Viewport.DrawingCanvas.Font.Color := clBlack;
  Viewport.DrawingCanvas.Font.Size:=FFontSize;

  try
    CanCache := not Viewport.Printing and not Viewport.ExportingBitmap and (Viewport.ViewType = fvPlan) and
      (Viewport.BackgroundImage.Bitmap = nil) and
      (Viewport.DrawingCanvas = Viewport.GetDrawingBuffer.Canvas) and
      (Viewport.GetDrawingBuffer.Width = Viewport.ClientWidth) and
      (Viewport.GetDrawingBuffer.Height = Viewport.ClientHeight);
    CacheKey := FillCacheKey;
    if UsingInteractionPreview then
    begin
      Viewport.PenColor := Viewport.Color;
      Viewport.SetPenWidth(5 * PenwidthFactor);
      Viewport.BrushStyle := bsClear;
    end
    else if CanCache and (FFillCache <> nil) and (FFillCacheKey = CacheKey) and
      not ShowMonochrome.Checked and ShowFillcolor.Checked then
    begin
      Viewport.DrawingCanvas.Draw(0, 0, FFillCache);
      Viewport.PenColor := Viewport.Color;
      Viewport.SetPenWidth(5 * PenwidthFactor);
      Viewport.BrushStyle := bsClear;
    end
    else
    if (not ShowMonochrome.Checked) and (ShowFillcolor.Checked) then
    begin
      for I := 1 to Freeship.Surface.NumberOfLayers do
        if Freeship.Layer[I - 1].ShowInLinesplan then
        begin
          Layer := Freeship.Surface.Layer[I - 1];
                    if Freeship.ProjectSettings.ProjectShadeUnderwaterShip then
            SubmColor := Freeship.ProjectSettings.ProjectUnderWaterColor
          else
            SubmColor := Layer.Color;
          for j := 1 to Layer.Count do
          begin
            Face := Layer.Items[J - 1];
            Done := False;
            if Face.Max.Z < Freeship.Surface.Min.Z +
            Freeship.ProjectSettings.ProjectDraft then
            begin
              for N := 1 to Face.ChildCount do
              begin
                Child := Face.Child[N - 1];
                for K := 3 to Child.NumberOfpoints do
                  AddTriangle(Child.Point[0].Coordinate, Child.Point[K - 2].Coordinate,
                    Child.Point[K - 1].Coordinate, SubmColor, Below, Layer.Symmetric);
              end;
              Done := True;
            end
            else if Face.Min.Z > Freeship.Surface.Min.Z + Freeship.ProjectSettings.ProjectDraft then
            begin
              for N := 1 to Face.ChildCount do
              begin
                Child := Face.Child[N - 1];
                for K := 3 to Child.NumberOfpoints do
                  AddTriangle(Child.Point[0].Coordinate, Child.Point[K - 2].Coordinate,
                    Child.Point[K - 1].Coordinate, Layer.Color, Above, Layer.Symmetric);
              end;
              Done := True;
            end;
            if not done then
              for N := 1 to Face.ChildCount do
                Processface(Face.Child[N - 1], Layer.Color, Layer.Symmetric);
          end;
        end;

      PrepareFillAtlas;
      SortTriangles(Below, 2);
      SortTriangles(Above, 2);
      DrawFillTriangles(Below, [lvProfile]);
      DrawFillTriangles(Above, [lvProfile]);
      SortTriangles(Below, 1);
      SortTriangles(Above, 1);
      // Aft bodyplan
      DrawFillTriangles(Below, [lvAftBody]);
      DrawFillTriangles(Above, [lvAftBody]);
      // frontview on bodyplan
      DrawFillTriangles(Below, [lvFrontBody]);
      DrawFillTriangles(Above, [lvFrontBody]);
      // plan view
      SortTriangles(Below, 3);
      SortTriangles(Above, 3);
      DrawFillTriangles(Below, [lvPlan]);
      DrawFillTriangles(Above, [lvPlan]);
      if VectorRecording then begin
        Viewport.DrawingCanvas:=VectorSavedCanvas;VectorRecording:=False;
        if FFillVector.EndRecord then begin
          FFillVectorKey:=FillCacheKey(False);
          if not DrawVectorFill then raise Exception.Create('Vector fill playback failed');
          TraceEvent('vector-built','native-resolution');
          FDiskFillDirty:=FDiskFillPath<>'';
        end else raise Exception.Create('Vector fill recording failed');
      end;

      if CanCache then
      begin
        if FFillCache = nil then FFillCache := TBitmap.Create;
        // Copy pixels into an independent bitmap. Assign can share a bitmap
        // handle, allowing later grid strokes to leak into the cached base.
        FFillCache.SetSize(Viewport.ClientWidth, Viewport.ClientHeight);
        FFillCache.Canvas.CopyRect(Rect(0, 0, FFillCache.Width, FFillCache.Height),
          Viewport.DrawingCanvas, Rect(0, 0, FFillCache.Width, FFillCache.Height));
        FFillCacheKey := CacheKey;
      end;
    end;

    if CaptureAtlas then
    begin
      if FInteractionImage=nil then FInteractionImage:=TBitmap.Create;
      FInteractionImage.SetSize(Viewport.ClientWidth,Viewport.ClientHeight);
      FInteractionImage.Canvas.CopyRect(Rect(0,0,FInteractionImage.Width,FInteractionImage.Height),
        Viewport.DrawingCanvas,Rect(0,0,FInteractionImage.Width,FInteractionImage.Height));
    end;
    if BuildingAtlas or CaptureAtlas then
    begin
      FInteractionKey := FillCacheKey(False);
    end;

    // Keep fixed-width strokes out of the transformable fill atlas as well.
    // The waterline band is a vector stroke, so its width stays native while
    // the hull fill is scaled during resize/pan/zoom.
    if (not ShowMonochrome.Checked) and ShowFillColor.Checked then
    begin
      // Draw dwl as a white band in profile and bodyplan views
      Viewport.PenColor := Viewport.Color;
      Viewport.SetPenWidth(5 * PenwidthFactor);
      Space := CalculateSpace(0.5 * textspace, FMin3D.X, FMax3D.X);
      Viewport.BrushStyle := bsClear;
      // draw dwl in profile
      DrawLineAtt(FProfileOrigin, SetPoint(FMin3D.X - Space, FMin3D.Z +
        FFreeship.ProjectSettings.ProjectDraft, 0), SetPoint(
        FMax3D.X + Space, FMin3D.Z + FFreeship.ProjectSettings.ProjectDraft, 0), '', False);
      // draw dwl in aft bodyplan
      Space := CalculateSpace(textspace, FMin3D.Y, FMax3D.Y);
      DrawLineAtt(FAftOrigin, SetPoint(-FMax3D.Y - Space, FMin3D.Z +
        FFreeship.ProjectSettings.ProjectDraft, 0), SetPoint(
        FMax3D.Y + Space, FMin3D.Z + FFreeship.ProjectSettings.ProjectDraft, 0), '', False);
      // draw dwl in front bodyplan
      DrawLineAtt(FFrontOrigin, SetPoint(-FMax3D.Y - Space, FMin3D.Z +
        FFreeship.ProjectSettings.ProjectDraft, 0), SetPoint(
        FMax3D.Y + Space, FMin3D.Z + FFreeship.ProjectSettings.ProjectDraft, 0), '', False);
    end;

    // Reserve the feature lines before placing any grid labels.
    CollectFeatureEdges;
    // Draw grid
    if ShowMonochrome.Checked then
      Viewport.PenColor := clSilver
    else
      Viewport.PenColor := clSilver;
    Viewport.BrushStyle := bsClear;
    // first draw grid in profile view
    Viewport.SetPenWidth(2 * PenwidthFactor);
    Space := CalculateSpace(0.2 * textspace, FMin3D.X, FMax3D.X);
    if ShowMonochrome.Checked then
      Viewport.FontColor := clBlack
    else
      Viewport.FontColor := clRed;
    // draw baseline
    DrawLineAtt(FProfileOrigin, SetPoint(FMin3D.X - Space, FMin3D.Z, 0),
      SetPoint(FMax3D.X + Space, FMin3D.Z, 0), rs_Base {UserString[184]} + #32 +
      ConvertDimension(
      FMin3D.Z, Freeship.ProjectSettings.ProjectUnits), False);
    // draw dwl
    DrawLineAtt(FProfileOrigin, SetPoint(FMin3D.X - Space, FMin3D.Z +
      FFreeship.ProjectSettings.ProjectDraft, 0), SetPoint(
      FMax3D.X + Space, FMin3D.Z + FFreeship.ProjectSettings.ProjectDraft, 0), rs_DWL {UserString[185]} + #32 +
      ConvertDimension(FMin3D.Z + FFreeship.ProjectSettings.ProjectDraft,
      Freeship.ProjectSettings.ProjectUnits), False);
    Viewport.SetPenWidth(PenwidthFactor);
    Viewport.FontColor := clBlack;
    for I := 1 to FFreeship.NumberofWaterlines do
    begin
      Tmp := -FFreeship.Waterline[I - 1].Plane.D;
      Str := ConvertDimension(Tmp, Freeship.ProjectSettings.ProjectUnits);
      DrawLineAtt(FProfileOrigin, SetPoint(FMin3D.X - Space, Tmp, 0),
        SetPoint(FMax3D.X + Space, Tmp, 0), Str, False);
    end;
    Space := CalculateSpace(textspace, FMin3D.Z, FMax3D.Z);
    for I := 1 to FFreeship.NumberofStations do
    begin
      Tmp := -FFreeship.Station[I - 1].Plane.D;
      Str := ConvertDimension(Tmp, Freeship.ProjectSettings.ProjectUnits);
      DrawLineAtt(FProfileOrigin, SetPoint(Tmp, FMin3D.Z - space, 0),
        SetPoint(Tmp, FMax3D.Z + space, 0), Str, True);
    end;
    // draw grid in aft body view
    Viewport.SetPenWidth(2 * PenwidthFactor);
    Space := CalculateSpace(textspace, FMin3D.Y, FMax3D.Y);
    if ShowMonochrome.Checked then
      Viewport.FontColor := clBlack
    else
      Viewport.FontColor := clRed;
    // draw base
    DrawLineAtt(FAftOrigin, SetPoint(-FMax3D.Y - Space, FMin3D.Z, 0),
      SetPoint(FMax3D.Y + Space, FMin3D.Z, 0), rs_Base {UserString[184]} + #32 + ConvertDimension(
      FMin3D.Z, Freeship.ProjectSettings.ProjectUnits), False);
    // draw dwl
    DrawLineAtt(FAftOrigin, SetPoint(-FMax3D.Y - Space, FMin3D.Z +
      FFreeship.ProjectSettings.ProjectDraft, 0), SetPoint(
      FMax3D.Y + Space, FMin3D.Z + FFreeship.ProjectSettings.ProjectDraft, 0), rs_DWL {UserString[185]} + #32 +
      ConvertDimension(FMin3D.Z + FFreeship.ProjectSettings.ProjectDraft,
      Freeship.ProjectSettings.ProjectUnits), False);
    Space := CalculateSpace(textspace, FMin3D.Z, FMax3D.Z);
    DrawLineAtt(FAftOrigin, SetPoint(0.0, FMin3D.Z - space, 0), SetPoint(
      0.0, FMax3D.Z + space, 0), rs_Center {UserString[245]}, True);
    Space := CalculateSpace(textspace, FMin3D.Y, FMax3D.Y);
    Viewport.FontColor := clBlack;
    Viewport.SetPenWidth(PenwidthFactor);
    for I := 1 to FFreeship.NumberofWaterlines do
    begin
      Tmp := -FFreeship.Waterline[I - 1].Plane.D;
      Str := ConvertDimension(Tmp, Freeship.ProjectSettings.ProjectUnits);
      DrawLineAtt(FAftOrigin, SetPoint(-FMax3D.Y - Space, Tmp, 0),
        SetPoint(FMax3D.Y + Space, Tmp, 0), Str, False);
    end;
    Space := CalculateSpace(textspace, FMin3D.Z, FMax3D.Z);
    for I := 1 to FFreeship.NumberofButtocks do
    begin
      Tmp := -FFreeship.Buttock[I - 1].Plane.D;
      Str := ConvertDimension(Tmp, Freeship.ProjectSettings.ProjectUnits);
      DrawLineAtt(FAftOrigin, SetPoint(Tmp, FMin3D.Z - space, 0), SetPoint(
        Tmp, FMax3D.Z + space, 0), Str, True);
      DrawLineAtt(FAftOrigin, SetPoint(-Tmp, FMin3D.Z - space, 0),
        SetPoint(-Tmp, FMax3D.Z + space, 0), Str, True);
    end;
    // draw grid in front body view
    Viewport.SetPenWidth(2 * PenwidthFactor);
    Space := CalculateSpace(textspace, FMin3D.Y, FMax3D.Y);
    if ShowMonochrome.Checked then
      Viewport.FontColor := clBlack
    else
      Viewport.FontColor := clRed;
    // draw baseline
    DrawLineAtt(FFrontOrigin, SetPoint(-FMax3D.Y - Space, FMin3D.Z, 0),
      SetPoint(FMax3D.Y + Space, FMin3D.Z, 0), rs_Base {UserString[184]} + #32 +
      ConvertDimension(
      FMin3D.Z, Freeship.ProjectSettings.ProjectUnits), False);
    // draw dwl
    DrawLineAtt(FFrontOrigin, SetPoint(-FMax3D.Y - Space, FMin3D.Z +
      FFreeship.ProjectSettings.ProjectDraft, 0), SetPoint(
      FMax3D.Y + Space, FMin3D.Z + FFreeship.ProjectSettings.ProjectDraft, 0), rs_DWL {UserString[185]} + #32 +
      ConvertDimension(FMin3D.Z + FFreeship.ProjectSettings.ProjectDraft,
      Freeship.ProjectSettings.ProjectUnits), False);
    Space := CalculateSpace(textspace, FMin3D.Z, FMax3D.Z);
    DrawLineAtt(FFrontOrigin, SetPoint(0.0, FMin3D.Z - space, 0), SetPoint(
      0.0, FMax3D.Z + space, 0), rs_Center {UserString[245]}, True);
    Space := CalculateSpace(textspace, FMin3D.Y, FMax3D.Y);
    Viewport.FontColor := clBlack;
    Viewport.SetPenWidth(PenwidthFactor);
    for I := 1 to FFreeship.NumberofWaterlines do
    begin
      Tmp := -FFreeship.Waterline[I - 1].Plane.D;
      Str := ConvertDimension(Tmp, Freeship.ProjectSettings.ProjectUnits);
      DrawLineAtt(FFrontOrigin, SetPoint(-FMax3D.Y - Space, Tmp, 0),
        SetPoint(FMax3D.Y + Space, Tmp, 0), Str, False);
    end;
    Space := CalculateSpace(textspace, FMin3D.Z, FMax3D.Z);
    for I := 1 to FFreeship.NumberofButtocks do
    begin
      Tmp := -FFreeship.Buttock[I - 1].Plane.D;
      Str := ConvertDimension(Tmp, Freeship.ProjectSettings.ProjectUnits);
      DrawLineAtt(FFrontOrigin, SetPoint(Tmp, FMin3D.Z - space, 0),
        SetPoint(Tmp, FMax3D.Z + space, 0), Str, True);
      DrawLineAtt(FFrontOrigin, SetPoint(-Tmp, FMin3D.Z - space, 0),
        SetPoint(-Tmp, FMax3D.Z + space, 0), Str, True);
    end;
    // draw grid in plan view
    Viewport.SetPenWidth(2 * PenwidthFactor);
    Space := CalculateSpace(0.2 * textspace, FMin3D.X, FMax3D.X);
    if ShowMonochrome.Checked then
      Viewport.FontColor := clBlack
    else
      Viewport.FontColor := clRed;
    DrawLineAtt(FPlanOrigin, SetPoint(FMin3D.X - Space, 0, 0), SetPoint(
      FMax3D.X + Space, 0, 0), rs_Center {UserString[245]}, False);
    Viewport.FontColor := clBlack;
    Viewport.SetPenWidth(PenwidthFactor);
    for I := 1 to FFreeship.NumberofButtocks do
    begin
      Tmp := -FFreeship.Buttock[I - 1].Plane.D;
      Str := ConvertDimension(Tmp, Freeship.ProjectSettings.ProjectUnits);
      DrawLineAtt(FPlanOrigin, SetPoint(FMin3D.X - Space, Tmp, 0),
        SetPoint(FMax3D.X + Space, Tmp, 0), Str, False);
      if (Freeship.NumberofDiagonals = 0) and (MirrorPlanview.Checked) then
        DrawLineAtt(FPlanOrigin, SetPoint(FMin3D.X - Space, -Tmp, 0), SetPoint(
          FMax3D.X + Space, -Tmp, 0), Str, False);
    end;
    Space := CalculateSpace(textspace, FMin3D.Y, FMax3D.Y);
    for I := 1 to FFreeship.NumberofStations do
    begin
      Tmp := -FFreeship.Station[I - 1].Plane.D;
      Str := ConvertDimension(Tmp, Freeship.ProjectSettings.ProjectUnits);
      if (Freeship.NumberofDiagonals = 0) and (MirrorPlanview.Checked) then
        DrawLineAtt(FPlanOrigin, SetPoint(Tmp, -FMax3D.Y - space, 0), SetPoint(
          Tmp, FMax3D.Y + space, 0), Str, True)
      else
        DrawLineAtt(FPlanOrigin, SetPoint(Tmp, -FDiagonalWidth - space, 0), SetPoint(
          Tmp, FMax3D.Y + space, 0), Str, True);
    end;

    // draw knuckle-lines
    //if not ShowFillColor.checked then
    begin
      if ShowFillColor.Checked then
        Viewport.SetPenWidth(1 * PenwidthFactor)
      else
        Viewport.SetPenWidth(2 * PenwidthFactor);
      Viewport.PenStyle := psSolid;
      if ShowMonochrome.Checked then
        Viewport.PenColor := clBlack
      else
        Viewport.PenColor := Freeship.Preferences.CreaseColor;
      for I := 1 to FreeShip.NumberOfLayers do
      begin
        Layer := FreeShip.Layer[I - 1];
        if Layer.ShowInLinesplan then
          for J := 1 to Layer.Count do
          begin
            Face := layer.Items[J - 1];
            for K := 1 to Face.ControlDescendantEdgeCount do
            begin
              Edge := Face.ControlDescendantEdge[K - 1];
              if Edge.Crease then
                DrawLine(Edge.StartPoint.Coordinate, Edge.EndPoint.Coordinate);
            end;
          end;
      end;
    end;

    FlushKnuckles;
    Viewport.SetPenWidth(PenwidthFactor);
    MidshipLocation := Freeship.ProjectSettings.ProjectSplitSectionLocation;
    // Draw stations
    if ShowMonochrome.Checked then
      Viewport.PenColor := clBlack
    else
      Viewport.PenColor := Freeship.Preferences.StationColor;
    for i := 1 to Freeship.NumberofStations do
      DrawIntersection(Freeship.Station[I - 1], [lvAftBody, lvFrontBody], psSolid);
    // Draw Buttocks
    if ShowMonochrome.Checked then
      Viewport.PenColor := clBlack
    else
      Viewport.PenColor := Freeship.Preferences.ButtockColor;
    for i := 1 to Freeship.NumberofButtocks do
      DrawIntersection(Freeship.Buttock[I - 1], [lvProfile], psSolid);
    // Draw Waterlines
    if ShowMonochrome.Checked then
      Viewport.PenColor := clBlack
    else
      Viewport.PenColor := Freeship.Preferences.WaterlineColor;
    for i := 1 to Freeship.NumberofWaterlines do
      DrawIntersection(Freeship.Waterline[I - 1], [lvPlan], psSolid);

    // Draw diagonals
    Viewport.PenWidth := PenwidthFactor;
    for I := 1 to Freeship.NumberofDiagonals do
    begin
      Diagonal := Freeship.Diagonal[I - 1];
      Plane.a := 0.0;
      Plane.b := 1 / Sqrt(2);
      Plane.c := -1 / sqrt(2);
      Plane.d := -Diagonal.Plane.d;
      if not Diagonal.Built then
        Diagonal.Rebuild;
      for J := 1 to Diagonal.Count do
      begin
        Viewport.SetPenWidth(1);
        if ShowMonochrome.Checked then
          Viewport.PenColor := clBlack
        else
          Viewport.PenColor := Freeship.Preferences.DiagonalColor;

        Spline := Diagonal.Items[J - 1];
        Spline.Fragments:=Steps;
        Pts3D := Spline.GetValues;
        Setlength(Pts, length(Pts3D));

        Min := 0;
        Max := 0;
        L:=0; Pn:=0;
        for K := 0 to length(Pts3D)-1 do
        begin
          P := Pts3D[K];
          Tmp := abs(Plane.A * P.x + Plane.B * P.y + Plane.C * P.z + Plane.D);
          if K = 0 then
          begin
            Min := Tmp;
            Max := Tmp;
          end
          else
          begin
            if Tmp < min then
              Min := Tmp;
            if Tmp > max then
              Max := Tmp;
          end;
          P:=Point3D(FPlanOrigin.X + P.X, FPlanOrigin.Y - abs(Tmp), 0.0);
          Pts[K] := Viewport.Project(P);
        end;

       {  // changed to above
        for K := 0 to steps do
        begin
          P := Spline.Value(K / steps, Pn1, Pn2);
          if (Pn<>Pn1) and Spline.Knuckle[Pn1] then // add knuckle
          begin
            Pkn := Spline.Point[Pn1];
            Pn:=Pn1;
            Tmp := abs(Plane.A * Pkn.x + Plane.B * Pkn.y + Plane.C * Pkn.z + Plane.D);
            if K = 0 then
            begin
              Min := Tmp;
              Max := Tmp;
            end
            else
            begin
              if Tmp < min then
                Min := Tmp;
              if Tmp > max then
                Max := Tmp;
            end;
            P:=Point3D(FPlanOrigin.X + Pkn.X, FPlanOrigin.Y - abs(Tmp), 0.0);
            Pts[L] := Viewport.Project(P);
            inc(L);
          end;

          Tmp := abs(Plane.A * P.x + Plane.B * P.y + Plane.C * P.z + Plane.D);
          if K = 0 then
          begin
            Min := Tmp;
            Max := Tmp;
          end
          else
          begin
            if Tmp < min then
              Min := Tmp;
            if Tmp > max then
              Max := Tmp;
          end;
          P:=Point3D(FPlanOrigin.X + P.X, FPlanOrigin.Y - abs(Tmp), 0.0);
          Pts[L] := Viewport.Project(P);
          inc(L);
        end;
        SetLength(Pts, L);
        }

        Viewport.Polyline(Pts);
        // draw as grid in bodyplan views
        Viewport.SetPenWidth(PenwidthFactor);
        if ShowMonochrome.Checked then
          Viewport.PenColor := clBlack
        else
          Viewport.PenColor := clSilver;
        // calculate height of intersection of diagonal with centerplane
        Tmp := -Diagonal.PLane.d / Diagonal.Plane.c;
        P1 := SetPoint(0.0, Min * Sin(DegToRad(45)), Tmp - Min * Sin(DegToRad(45)));
        P2 := SetPoint(0.0, Max * Sin(DegToRad(45)), Tmp - Max * Sin(DegToRad(45)));
        DrawDiagonalLine(FAftOrigin, P1, P2);
        DrawDiagonalLine(FFrontOrigin, P1, P2);
      end;
    end;
    DrawPendingLabels;
    if not Viewport.Printing and not Viewport.ExportingBitmap then
    begin
      FLastLabelContext:=LabelContextKey;
      FLastLabelScale:=Viewport.Scale*Viewport.Zoom;
    end;
    if UsingInteractionPreview then TraceEvent('cached-fill','ms=' + IntToStr(GetTickCount64-PaintStarted))
    else TraceEvent('full', 'ms=' + IntToStr(GetTickCount64-PaintStarted) +
      '; zoom=' + FloatToStr(Viewport.Zoom));
  finally
    if VectorRecording then begin
      Viewport.DrawingCanvas:=VectorSavedCanvas;VectorRecording:=False;FFillVector.Clear;
    end;
    Viewport.LabelLayout.EndFrame;
    Viewport.LabelLayout.TranslationOnly:=False;
    Screen.Cursor := Prevcursor;
  end;
end;{TFreeLinesplanFrame.ViewportRedraw}

procedure TFreeLinesplanFrame.ZoomExtentsExecute(Sender: TObject);
begin
  Viewport.ZoomExtents;
end;{TFreeLinesplanFrame.ZoomExtentsExecute}

procedure TFreeLinesplanFrame.ZoomInExecute(Sender: TObject);
begin
  Viewport.ZoomIn;
end;{TFreeLinesplanFrame.ZoomInExecute}

procedure TFreeLinesplanFrame.ZoomOutExecute(Sender: TObject);
begin
  Viewport.ZoomOut;
end;{TFreeLinesplanFrame.ZoomOutExecute}

procedure TFreeLinesplanFrame.ShowFillColorExecute(Sender: TObject);
begin
  FinishInteraction(nil);
  ShowFillcolor.Checked := not ShowFillcolor.Checked;
  UpdateMenu;
  Viewport.Refresh;
end;{TFreeLinesplanFrame.ShowFillColorExecute}

procedure TFreeLinesplanFrame.PrintExecute(Sender: TObject);
begin
  FinishInteraction(nil);
  if Viewport.Width > Viewport.Height then
    Printer.Orientation := poLandscape
  else
    Printer.Orientation := poPortrait;
  if PrintDialog.Execute then
    Viewport.Print(FFreeship.ProjectSettings.ProjectUnits, True, rs_FREE_ship_linesplan {UserString[246]});
end;{TFreeLinesplanFrame.PrintExecute}

procedure TFreeLinesplanFrame.ViewportMouseMove(Sender: TObject; Shift: TShiftState;
  X, Y: integer);
var
  P: TPoint;
begin
  if (ssLeft in Shift) or (ssRight in Shift) then FInteractionDragging := True;
  if ssLeft in Shift then
  begin
    // Zoom in or zoom out
    if abs(FInitialPosition.Y - Y) > 4 then
    begin
      BeginInteraction;
      if Y < FInitialPosition.Y then
        Viewport.ZoomIn
      else
      if Y > FInitialPosition.Y then
        Viewport.ZoomOut;
      FInitialPosition.X := X;
      FInitialPosition.Y := Y;
    end;
  end
  else if ssRight in Shift then
  begin
    // Pan the window left, right, top or bottom
    // Apply the drag threshold once; an active pan follows every pixel.
    if (abs(FInitialPosition.X - X) > 4) or (abs(FInitialPosition.Y - Y) > 4) then
      FPanDragStarted := True;
    if FPanDragStarted and ((FInitialPosition.X <> X) or (FInitialPosition.Y <> Y)) then
    begin
      P.X := Viewport.Pan.X + X - FInitialPosition.X;
      P.Y := Viewport.Pan.Y + Y - FInitialPosition.Y;
      BeginInteraction;
      Viewport.Pan := P;
      FInitialPosition.X := X;
      FInitialPosition.Y := Y;
    end;
  end;
end;{TFreeLinesplanFrame.ViewportMouseMove}

procedure TFreeLinesplanFrame.ViewportMouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: integer);
begin
  FInteractionDragging := Button in [mbLeft,mbRight];
  FPanDragStarted := False;
  FInitialPosition.X := X;
  FInitialPosition.Y := Y;
end;{TFreeLinesplanFrame.ViewportMouseDown}

procedure TFreeLinesplanFrame.SaveBitmapExecute(Sender: TObject);
var
  Str: string;

begin
  FinishInteraction(nil);
  Str := FFreeShip.Preferences.ExportDirectory;
  if Str[Length(Str)] <> '\' then
    Str := Str + '\';
  Str := Str + ChangeFileExt(ExtractFilename(FFreeship.FileName), '') + '_Linesplan.bmp';
  Viewport.SaveAsBitmap(Str);
end;{TFreeLinesplanFrame.SaveBitmapExecute}

procedure TFreeLinesplanFrame.UseLightsExecute(Sender: TObject);
begin
  FinishInteraction(nil);
  UseLights.Checked := not UseLights.Checked;
  UpdateMenu;
  Viewport.Refresh;
end;{TFreeLinesplanFrame.UseLightsExecute}

procedure TFreeLinesplanFrame.ShowMonochromeExecute(Sender: TObject);
begin
  FinishInteraction(nil);
  ShowMonochrome.Checked := not ShowMonochrome.Checked;
  UpdateMenu;
  Viewport.Refresh;
end;{TFreeLinesplanFrame.ShowMonochromeExecute}

procedure TFreeLinesplanFrame.MirrorPlanViewExecute(Sender: TObject);
begin
  FinishInteraction(nil);
  MirrorPlanview.Checked := not MirrorPlanview.Checked;
  UpdateMenu;
  Viewport.ZoomExtents;
end;{TFreeLinesplanFrame.MirrorPlanViewExecute}

procedure TFreeLinesplanFrame.ExportDXFExecute(Sender: TObject);
var
  SaveDialog: TSaveDialog;
  Strings: TStringList;
  Str: string;
  Space, Tmp: TFloatType;
  SplitSectionLocation: TFloatType;
  Min, Max: TFloatType;
  I, J, K: integer;
  Edge: TFreeSubdivisionEdge;
  P1, P2: T3DCoordinate;
  Diagonal: TFreeIntersection;
  Plane: T3DPlane;
  Spline: TFreeSpline;
  EdgePointLists: TFasterListTFasterListTFreeSubdivisionPoint;
  Points: TFasterListTFreeSubdivisionPoint;
  SplineValues: T3DCoordinateArray;

  procedure WriteDXFPoint(N: integer; P: T3DCoordinate);
  begin
    Strings.Add(IntToStr(N) + EOL + FloatToDec(P.X, 6));
    Strings.Add(IntToStr(N + 10) + EOL + FloatToDec(P.Y, 6));
  end;{WriteDXFPoint}

  procedure AddLine(P1, P2: T3DCoordinate; Views: TLinesplanViews;
    Layername: string; Color: TColor);
  var
    Startp, Endp: T3DCoordinate;
  begin
    if lvProfile in views then
    begin
      StartP.X := FProfileOrigin.X + P1.X;
      StartP.Y := FProfileOrigin.Y + P1.Z;
      StartP.Z := 0.0;
      EndP.X := FProfileOrigin.X + P2.X;
      EndP.Y := FProfileOrigin.Y + P2.Z;
      EndP.Z := 0.0;
    end;
    if lvAftBody in views then
    begin
      StartP.X := FAftOrigin.X - P1.Y;
      StartP.Y := FAftOrigin.Y + P1.Z;
      StartP.Z := 0.0;
      EndP.X := FAftOrigin.X - P2.Y;
      EndP.Y := FAftOrigin.Y + P2.Z;
      EndP.Z := 0.0;
    end;
    if lvFrontBody in views then
    begin
      StartP.X := FFrontOrigin.X - P1.Y;
      StartP.Y := FFrontOrigin.Y + P1.Z;
      StartP.Z := 0.0;
      EndP.X := FFrontOrigin.X - P2.Y;
      EndP.Y := FFrontOrigin.Y + P2.Z;
      EndP.Z := 0.0;
    end;
    if lvPlan in views then
    begin
      StartP.X := FPlanOrigin.X + P1.X;
      StartP.Y := FPlanOrigin.Y + P1.Y;
      StartP.Z := 0.0;
      EndP.X := FPlanOrigin.X + P2.X;
      EndP.Y := FPlanOrigin.Y + P2.Y;
      EndP.Z := 0.0;
    end;
    Strings.Add('0' + EOL + 'LINE');
    Strings.Add('8' + EOL + LayerName);
    Strings.Add('62' + EOL + IntToStr(FindDXFColorIndex(Color)));
    WriteDXFPoint(10, StartP);
    WriteDXFPoint(11, EndP);
  end;{AddLine}

  procedure AddSpline(Spline: TFreeSpline; Views: TLinesplanViews;
    Layername: string; Color: TColor);
  var
    Points: array of T3DCoordinate;
    P: T3DCoordinate;
    I,J: integer;
    Params: TFloatArray;
    NParams, NValues: integer;
    Pn, Pn1, Pn2: integer;
  begin
    NParams := 0;
    Setlength(Params, Spline.NumberOfPoints);
    // count number of knucklepoints
    if not Spline.Built then
      Spline.Rebuild;
    for I := 2 to Spline.NumberOfPoints - 1 do
    begin
      if Spline.Knuckle[I - 1] then
      begin
        Params[NParams] := Spline.Parameter[I - 1];
        Inc(NParams);
      end;
    end;
    Spline.Fragments := 100;
    Setlength(Params, NParams + Spline.Fragments);
    for I := 1 to Spline.Fragments do
    begin
      Params[NParams] := (I - 1) / (Spline.Fragments - 1);
      Inc(NParams);
    end;
    SortFloatArray(Params, NParams);

    {Setlength(Points, NParams + Spline.NumberOfPoints);
    J:=0; Pn:=0;
    for I := 0 to NParams - 1 do
    begin
      P:=Spline.Value(Params[I], Pn1, Pn2);
      if (Pn<>Pn1) and Spline.Knuckle[Pn1] then
      begin
        Points[J] := Spline.Point[Pn1];
        Pn:=Pn1;
        inc(J);
      end;
      Points[J] := P;
    end;
    Setlength(Points, J+1);
    }
    Points := Spline.GetValues;
    NValues := length(Points);

    Strings.Add('0' + EOL + 'POLYLINE');
    Strings.Add('8' + EOL + LayerName);   // layername
    Strings.Add('62' + EOL + IntToStr(FindDXFColorIndex(Color)));
    Strings.Add('66' + EOL + '1');    // vertices follow
    for I := 0 to NValues - 1 do
    begin
      P.Z := 0.0;
      if lvProfile in views then
      begin
        P.X := FProfileOrigin.X + Points[I].X;
        P.Y := FProfileOrigin.Y + Points[I].Z;
      end;
      if lvAftBody in views then
      begin
        P.X := FAftOrigin.X - Points[I].Y;
        P.Y := FAftOrigin.Y + Points[I].Z;
      end;
      if lvFrontBody in views then
      begin
        P.X := FFrontOrigin.X - Points[I].Y;
        P.Y := FFrontOrigin.Y + Points[I].Z;
      end;
      if lvPlan in views then
      begin
        P.X := FPlanOrigin.X + Points[I].X;
        P.Y := FPlanOrigin.Y + Points[I].Y;
      end;
      Strings.Add('0' + EOL + 'VERTEX');
      Strings.Add('8' + EOL + LayerName);
      Strings.Add('10' + EOL + FloatToDec(P.X, 4));
      Strings.Add('20' + EOL + FloatToDec(P.Y, 4));
    end;
    Strings.Add('0' + EOL + 'SEQEND');

    if (lvAftBody in views) or (lvFrontBody in views) or
      ((lvPlan in views) and (Freeship.NumberofDiagonals = 0) and (MirrorPlanView.Checked)) then
    begin
      // mirror line
      Strings.Add('0' + EOL + 'POLYLINE');
      Strings.Add('8' + EOL + LayerName);   // layername
      Strings.Add('62' + EOL + IntToStr(FindDXFColorIndex(Color)));
      Strings.Add('66' + EOL + '1');    // vertices follow
      for I := 0 to NValues - 1 do
      begin
        P.Z := 0.0;
        if lvAftBody in views then
        begin
          P.X := FAftOrigin.X + Points[I].Y;
          P.Y := FAftOrigin.Y + Points[I].Z;
        end;
        if lvFrontBody in views then
        begin
          P.X := FFrontOrigin.X + Points[I].Y;
          P.Y := FFrontOrigin.Y + Points[I].Z;
        end;
        if lvPlan in views then
        begin
          P.X := FPlanOrigin.X + Points[I].X;
          P.Y := FPlanOrigin.Y - Points[I].Y;
        end;

        Strings.Add('0' + EOL + 'VERTEX');
        Strings.Add('8' + EOL + LayerName);
        Strings.Add('10' + EOL + FloatToDec(P.X, 4));
        Strings.Add('20' + EOL + FloatToDec(P.Y, 4));
      end;
      Strings.Add('0' + EOL + 'SEQEND');
    end;
  end;{AddSpline}

  procedure AddEdgeLoop(const Points: TFasterListTFreeSubdivisionPoint;
    Views: TLinesplanViews; Layername: string; Color: TColor);
  var
    Point: TFreeSubdivisionPoint;
    P: T3DCoordinate;
    I: integer;
  begin
    Strings.Add('0' + EOL + 'POLYLINE');
    Strings.Add('8' + EOL + LayerName);   // layername
    Strings.Add('62' + EOL + IntToStr(FindDXFColorIndex(Color)));
    Strings.Add('66' + EOL + '1');    // vertices follow
    for I := 1 to Points.Count do
    begin
      Point := Points[I - 1];
      P.Z := 0.0;
      if lvProfile in views then
      begin
        P.X := FProfileOrigin.X + Point.Coordinate.X;
        P.Y := FProfileOrigin.Y + Point.Coordinate.Z;
      end;
      if lvAftBody in views then
      begin
        P.X := FAftOrigin.X - Point.Coordinate.Y;
        P.Y := FAftOrigin.Y + Point.Coordinate.Z;
      end;
      if lvFrontBody in views then
      begin
        P.X := FFrontOrigin.X - Point.Coordinate.Y;
        P.Y := FFrontOrigin.Y + Point.Coordinate.Z;
      end;
      if lvPlan in views then
      begin
        P.X := FPlanOrigin.X + Point.Coordinate.X;
        P.Y := FPlanOrigin.Y + Point.Coordinate.Y;
      end;
      Strings.Add('0' + EOL + 'VERTEX');
      Strings.Add('8' + EOL + LayerName);
      Strings.Add('10' + EOL + FloatToDec(P.X, 4));
      Strings.Add('20' + EOL + FloatToDec(P.Y, 4));
    end;
    Strings.Add('0' + EOL + 'SEQEND');

    if (lvAftBody in views) or (lvFrontBody in views) or
      ((lvPlan in views) and (Freeship.NumberofDiagonals = 0) and (MirrorPlanView.Checked)) then
    begin
      // mirror line
      Strings.Add('0' + EOL + 'POLYLINE');
      Strings.Add('8' + EOL + LayerName);   // layername
      Strings.Add('62' + EOL + IntToStr(FindDXFColorIndex(Color)));
      Strings.Add('66' + EOL + '1');    // vertices follow
      for I := 1 to Points.Count do
      begin
        Point := Points[I - 1];
        P.Z := 0.0;
        if lvAftBody in views then
        begin
          P.X := FAftOrigin.X + Point.Coordinate.Y;
          P.Y := FAftOrigin.Y + Point.Coordinate.Z;
        end;
        if lvFrontBody in views then
        begin
          P.X := FFrontOrigin.X + Point.Coordinate.Y;
          P.Y := FFrontOrigin.Y + Point.Coordinate.Z;
        end;
        if lvPlan in views then
        begin
          P.X := FPlanOrigin.X + Point.Coordinate.X;
          P.Y := FPlanOrigin.Y - Point.Coordinate.Y;
        end;

        Strings.Add('0' + EOL + 'VERTEX');
        Strings.Add('8' + EOL + LayerName);
        Strings.Add('10' + EOL + FloatToDec(P.X, 4));
        Strings.Add('20' + EOL + FloatToDec(P.Y, 4));
      end;
      Strings.Add('0' + EOL + 'SEQEND');
    end;
  end;{AddSpline}

  procedure AddIntersection(Intersection: TFreeIntersection;
    Views: TLinesplanViews; Layername: string; Color: TColor);
  var
    I: integer;
  begin
    if not Intersection.Built then
      Intersection.Rebuild;
    for I := 1 to Intersection.Count do
      AddSpline(Intersection.Items[I - 1], Views, Layername, Color);
  end;
  {AddIntersection}
begin
  FinishInteraction(nil);
  Str := IncludeTrailingPathDelimiter(FFreeShip.Preferences.ExportDirectory);
  Str := Str + ChangeFileExt(ExtractFilename(FFreeship.FileName), '') + '_Linesplan';
  SaveDialog := TSaveDialog.Create(Owner);
  SaveDialog.InitialDir := Freeship.Preferences.ExportDirectory;
  SaveDialog.FileName := ChangeFileExt(Str, '');
  SaveDialog.Filter := createDialogFilter(rsAutocadDxfFile,['dxf']);
  Savedialog.Options := [ofOverwritePrompt, ofHideReadOnly];
  if SaveDialog.Execute then
  begin
    Freeship.Preferences.ExportDirectory := ExtractFilePath(SaveDialog.FileName);
    SplitSectionLocation := Freeship.ProjectSettings.ProjectSplitSectionLocation;

    EdgePointLists := TFasterListTFasterListTFreeSubdivisionPoint.Create;
    Freeship.Surface.ExtractAllEdgeLoops(EdgePointLists);
    Strings := TStringList.Create;
    Strings.Add('0' + EOL + 'SECTION');
    Strings.Add('2' + EOL + 'ENTITIES');
    // PROFILE VIEW
    Space := CalculateSpace(0.5 * textspace, FMin3D.X, FMax3D.X);
    // draw baseline
    AddLine(SetPoint(FMin3D.X - Space, FMin3D.Z, 0), SetPoint(
      FMax3D.X + Space, FMin3D.Z, 0), [lvProfile], rs_Base {UserString[184]}, Freeship.Preferences.GridColor);
    // draw dwl
    AddLine(SetPoint(FMin3D.X - Space, 0, FMin3D.Z + FFreeship.ProjectSettings.ProjectDraft),
      SetPoint(FMax3D.X + Space, 0, FMin3D.Z + FFreeship.ProjectSettings.ProjectDraft),
      [lvProfile], rs_DWL {UserString[185]}, clRed);
    for I := 1 to FFreeship.NumberofWaterlines do
    begin
      Tmp := -FFreeship.Waterline[I - 1].Plane.D;
      AddLine(SetPoint(FMin3D.X - Space, 0, Tmp), SetPoint(FMax3D.X + Space, 0, Tmp),
        [lvProfile], 'wlgrid', Freeship.Preferences.GridColor);
    end;
    Space := CalculateSpace(textspace, FMin3D.Z, FMax3D.Z);
    for I := 1 to FFreeship.NumberofStations do
    begin
      Tmp := -FFreeship.Station[I - 1].Plane.D;
      AddLine(SetPoint(Tmp, 0, FMin3D.Z - space), SetPoint(Tmp, 0, FMax3D.Z + space),
        [lvProfile], 'stationgrid', Freeship.Preferences.GridColor);
    end;
    // draw buttocks
    for I := 1 to Freeship.NumberofButtocks do
      AddIntersection(Freeship.Buttock[I - 1], [lvProfile], 'buttocks',
        Freeship.Preferences.ButtockColor);
    // Add knuckle lines
    for I := 1 to EdgePointLists.Count do
    begin
      Points:=EdgePointLists[I-1];
      //Points := TFasterListTFreeSubdivisionPoint.Create;
      //Points.Add(EdgePointLists[I - 1].StartPoint);
      //Points.Add(EdgePointLists[I - 1].EndPoint);
      AddEdgeLoop(Points, [lvProfile], 'Knuckle_lines',
        Freeship.Preferences.CreaseColor);
    end;

    // AFT VIEW OF BODYPLAN
    Space := CalculateSpace(0.5 * textspace, -FMax3D.Y, FMax3D.Y);
    // draw baseline
    AddLine(SetPoint(0.0, -FMax3D.Y - Space, 0.0), SetPoint(0.0, FMax3D.Y + Space, 0.0),
      [lvAftBody], rs_Base {UserString[184]}, Freeship.Preferences.GridColor);
    // draw dwl
    AddLine(SetPoint(0.0, -FMax3D.Y - Space, FMin3D.Z +
      FFreeship.ProjectSettings.ProjectDraft), SetPoint(0.0, FMax3D.Y + Space,
      FMin3D.Z + FFreeship.ProjectSettings.ProjectDraft), [lvAftBody], rs_DWL {UserString[185]}, clRed);
    for I := 1 to FFreeship.NumberofWaterlines do
    begin
      Tmp := -FFreeship.Waterline[I - 1].Plane.D;
      AddLine(SetPoint(0.0, -FMax3D.Y - Space, Tmp), SetPoint(
        0.0, FMax3D.Y + Space, Tmp), [lvAftBody], 'wlgrid', Freeship.Preferences.GridColor);
    end;
    Space := CalculateSpace(textspace, FMin3D.Z, FMax3D.Z);
    // draw centerline
    AddLine(SetPoint(0.0, 0.0, FMin3D.Z - space), SetPoint(0.0, 0.0, FMax3D.Z + space),
      [lvAftBody], rs_Center {UserString[245]}, clRed);
    for I := 1 to FFreeship.NumberofButtocks do
    begin
      Tmp := -FFreeship.Buttock[I - 1].Plane.D;
      AddLine(SetPoint(0.0, Tmp, FMin3D.Z - space), SetPoint(
        0.0, Tmp, FMax3D.Z + space), [lvAftBody], 'buttockgrid', Freeship.Preferences.GridColor);
      AddLine(SetPoint(0.0, -Tmp, FMin3D.Z - space), SetPoint(
        0.0, -Tmp, FMax3D.Z + space), [lvAftBody], 'buttockgrid', Freeship.Preferences.GridColor);
    end;
    // draw stations
    for I := 1 to Freeship.NumberofStations do
      if -Freeship.Station[I - 1].Plane.d <= SplitSectionLocation then
        AddIntersection(Freeship.Station[I - 1], [lvAftBody], 'stations',
          Freeship.Preferences.StationColor);
    // Add knuckle lines
    for I := 1 to FreeShip.Surface.NumberOfSubDivEdges do
    begin
      Edge := FreeShip.Surface.SubDivEdge[I - 1];
      if (Edge.Crease) and (Edge.StartPoint.Coordinate.X <= SplitSectionLocation) and
        (Edge.EndPoint.Coordinate.X <= SplitSectionLocation) then
      begin
        P1 := Edge.StartPoint.Coordinate;
        P2 := Edge.EndPoint.Coordinate;
        AddLine(P1, P2, [lvAftBody], 'Knuckle_lines', Freeship.Preferences.CreaseColor);
        P1.Y := -P1.Y;
        P2.Y := -P2.Y;
        AddLine(P1, P2, [lvAftBody], 'Knuckle_lines', Freeship.Preferences.CreaseColor);
      end;
    end;

    // FRONT VIEW OF BODYPLAN
    Space := CalculateSpace(0.5 * textspace, -FMax3D.Y, FMax3D.Y);
    // draw baseline
    AddLine(SetPoint(0.0, -FMax3D.Y - Space, 0.0), SetPoint(0.0, FMax3D.Y + Space, 0.0),
      [lvFrontBody], rs_Base {UserString[184]}, Freeship.Preferences.GridColor);
    // draw dwl
    AddLine(SetPoint(0.0, -FMax3D.Y - Space, FMin3D.Z +
      FFreeship.ProjectSettings.ProjectDraft), SetPoint(0.0, FMax3D.Y + Space,
      FMin3D.Z + FFreeship.ProjectSettings.ProjectDraft), [lvFrontBody], rs_DWL {UserString[185]}, clRed);
    for I := 1 to FFreeship.NumberofWaterlines do
    begin
      Tmp := -FFreeship.Waterline[I - 1].Plane.D;
      AddLine(SetPoint(0.0, -FMax3D.Y - Space, Tmp), SetPoint(
        0.0, FMax3D.Y + Space, Tmp), [lvFrontBody], 'wlgrid', Freeship.Preferences.GridColor);
    end;
    Space := CalculateSpace(textspace, FMin3D.Z, FMax3D.Z);
    // draw centerline
    AddLine(SetPoint(0.0, 0.0, FMin3D.Z - space), SetPoint(0.0, 0.0, FMax3D.Z + space),
      [lvFrontBody], rs_Center {UserString[245]}, clRed);
    for I := 1 to FFreeship.NumberofButtocks do
    begin
      Tmp := -FFreeship.Buttock[I - 1].Plane.D;
      AddLine(SetPoint(0.0, Tmp, FMin3D.Z - space), SetPoint(
        0.0, Tmp, FMax3D.Z + space), [lvFrontBody], 'buttockgrid', Freeship.Preferences.GridColor);
      AddLine(SetPoint(0.0, -Tmp, FMin3D.Z - space), SetPoint(
        0.0, -Tmp, FMax3D.Z + space), [lvFrontBody], 'buttockgrid', Freeship.Preferences.GridColor);
    end;
    // draw stations
    for I := 1 to Freeship.NumberofStations do
      if -Freeship.Station[I - 1].Plane.d >= SplitSectionLocation then
        AddIntersection(Freeship.Station[I - 1], [lvFrontBody], 'stations',
          Freeship.Preferences.StationColor);
    // Add knuckle lines
    for I := 1 to FreeShip.Surface.NumberOfSubDivEdges do
    begin
      Edge := FreeShip.Surface.SubDivEdge[I - 1];
      if (Edge.Crease) and (Edge.StartPoint.Coordinate.X >= SplitSectionLocation) and
        (Edge.EndPoint.Coordinate.X >= SplitSectionLocation) then
      begin
        P1 := Edge.StartPoint.Coordinate;
        P2 := Edge.EndPoint.Coordinate;
        AddLine(P1, P2, [lvFrontBody], 'Knuckle_lines',
          Freeship.Preferences.CreaseColor);
        P1.Y := -P1.Y;
        P2.Y := -P2.Y;
        AddLine(P1, P2, [lvFrontBody], 'Knuckle_lines',
          Freeship.Preferences.CreaseColor);
      end;
    end;
    // PLAN VIEW
    Space := CalculateSpace(0.5 * textspace, FMin3D.X, FMax3D.X);
    // draw centerline
    AddLine(SetPoint(FMin3D.X - Space, 0.0, 0.0), SetPoint(FMax3D.X + Space, 0.0, 0.0),
      [lvPlan], rs_Center {UserString[245]}, clRed);
    for I := 1 to FFreeship.NumberofButtocks do
    begin
      Tmp := -FFreeship.Buttock[I - 1].Plane.D;
      AddLine(SetPoint(FMin3D.X - Space, Tmp, 0.0), SetPoint(
        FMax3D.X + space, Tmp, 0.0), [lvPlan], 'buttockgrid', Freeship.Preferences.GridColor);
      if (Freeship.NumberofDiagonals = 0) and (MirrorPlanView.Checked) then
        AddLine(SetPoint(FMin3D.X - space, -Tmp, 0.0), SetPoint(FMax3D.X + space, -Tmp, 0.0),
          [lvPlan], 'buttockgrid', Freeship.Preferences.GridColor);
    end;
    // stations
    Space := CalculateSpace(textspace, FMin3D.Y, FMax3D.Y);
    for I := 1 to FFreeship.NumberofStations do
    begin
      Tmp := -FFreeship.Station[I - 1].Plane.D;
      if (Freeship.NumberofDiagonals = 0) and (MirrorPlanview.Checked) then
        AddLine(SetPoint(Tmp, -FMax3D.Y - space, 0), SetPoint(Tmp, FMax3D.Y + space, 0),
          [lvPlan], 'stationgrid', Freeship.Preferences.GridColor)
      else
        AddLine(SetPoint(Tmp, -FDiagonalWidth - space, 0), SetPoint(Tmp, FMax3D.Y + space, 0),
          [lvPlan], 'stationgrid', Freeship.Preferences.GridColor);
    end;
    // draw waterlines
    for I := 1 to Freeship.NumberofWaterlines do
      AddIntersection(Freeship.Waterline[I - 1], [lvPLan], 'waterlines',
        Freeship.Preferences.WaterlineColor);

    // draw diagonals
    for I := 1 to Freeship.NumberofDiagonals do
    begin
      Diagonal := Freeship.Diagonal[I - 1];
      Plane.a := 0.0;
      Plane.b := 1 / Sqrt(2);
      Plane.c := -1 / sqrt(2);
      Plane.d := -Diagonal.Plane.d;
      if not Diagonal.Built then
        Diagonal.Rebuild;
      for J := 1 to Diagonal.Count do
      begin
        Spline := Diagonal.Items[J - 1];
        Min := 0;
        Max := 0;
        Strings.Add('0' + EOL + 'POLYLINE');
        Strings.Add('8' + EOL + 'Diagonals');   // layername
        Strings.Add('62' + EOL + IntToStr(FindDXFColorIndex(
          Freeship.Preferences.DiagonalColor)));
        Strings.Add('66' + EOL + '1');    // vertices follow

        Spline.Fragments:=100;
        SplineValues := Spline.GetValues;
        for k := 0 to length(SplineValues)-1 do
        begin
          //P1 := Spline.Value(K / 100, Pn1, Pn2);
          P1:=SplineValues[k];
          Tmp := abs(Plane.A * P1.x + Plane.B * P1.y + Plane.C * P1.z + Plane.D);
          if K = 0 then
          begin
            Min := Tmp;
            Max := Tmp;
          end
          else
          begin
            if Tmp < min then
              Min := Tmp;
            if Tmp > max then
              Max := Tmp;
          end;
          P2.X := FPlanOrigin.X + P1.X;
          P2.Y := FPlanOrigin.Y - abs(Tmp);
          P2.Z := 0.0;
          Strings.Add('0' + EOL + 'VERTEX');
          Strings.Add('8' + EOL + 'Diagonals');
          Strings.Add('10' + EOL + FloatToDec(P2.X, 4));
          Strings.Add('20' + EOL + FloatToDec(P2.Y, 4));
        end;
        Strings.Add('0' + EOL + 'SEQEND');
        // draw as grid in bodyplan views
        // calculate height of intersection of diagonal with centerplane
        Tmp := -Diagonal.Plane.d / Diagonal.Plane.c;
        P1 := SetPoint(0.0, Min * Sin(DegToRad(45)), Tmp - Min * Sin(DegToRad(45)));
        P2 := SetPoint(0.0, Max * Sin(DegToRad(45)), Tmp - Max * Sin(DegToRad(45)));
        AddLine(P1, P2, [lvAftBody], 'diagonalgrid', freeship.Preferences.GridColor);
        AddLine(P1, P2, [lvFrontBody], 'diagonalgrid', freeship.Preferences.GridColor);
        P1.Y := -P1.Y;
        P2.Y := -P2.Y;
        AddLine(P1, P2, [lvAftBody], 'diagonalgrid', freeship.Preferences.GridColor);
        AddLine(P1, P2, [lvFrontBody], 'diagonalgrid', freeship.Preferences.GridColor);
      end;
    end;
    // Add knuckle lines
    for I := 1 to EdgePointLists.Count do
    begin
      Points:=EdgePointLists[I-1];
      AddEdgeLoop(Points, [lvPlan], 'Knuckle_lines', Freeship.Preferences.CreaseColor);
    end;

    Strings.Add('0' + EOL + 'ENDSEC');
    Strings.Add('0' + EOL + 'EOF');
    Strings.SaveToFile(ChangeFileExt(SaveDialog.FileName, '.dxf'));
    FreeAndNil(Strings);

    // Destroy extracted edgeloops
    for I := 1 to EdgePointLists.Count do
    begin
      Points:=EdgePointLists[I-1];
      FreeAndNil(Points);
    end;
    FreeAndNil(EdgePointLists);
  end;
  FreeAndNil(SaveDialog);
end;

end.
